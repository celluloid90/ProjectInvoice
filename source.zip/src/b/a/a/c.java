// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package b.a.a;


public class c
{

    private String a;
    private int b;
    private boolean c;
    private boolean d;

    public c(String s, int i, int j)
    {
        a = s;
        if ((i & 1) == 1)
        {
            c = true;
        }
        if ((i & 2) == 2)
        {
            d = true;
        }
        b = j;
    }

    public String a()
    {
        StringBuilder stringbuilder = new StringBuilder(String.valueOf(a));
        String s;
        if (b())
        {
            s = " Bold";
        } else
        {
            s = "";
        }
        stringbuilder = stringbuilder.append(s);
        if (c())
        {
            s = " Italic";
        } else
        {
            s = "";
        }
        return stringbuilder.append(s).toString();
    }

    public boolean b()
    {
        return c;
    }

    public boolean c()
    {
        return d;
    }

    public String d()
    {
        return a;
    }
}
