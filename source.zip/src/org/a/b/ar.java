// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.Provider;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.X509Certificate;
import javax.crypto.Cipher;
import org.a.a.ba;
import org.a.a.bd;
import org.a.a.be;
import org.a.a.c.a;
import org.a.a.c.aa;
import org.a.a.c.b;
import org.a.a.c.c;
import org.a.a.c.h;
import org.a.a.c.y;
import org.a.a.c.z;
import org.a.a.e;
import org.a.a.i;
import org.a.a.k;
import org.a.a.m;
import org.a.a.n;
import org.a.a.r;
import org.a.a.t;

// Referenced classes of package org.a.b:
//            aq, k, u, ac, 
//            ab, m, v, ap, 
//            g, aa

public class ar
{

    private aq a;
    private z b;
    private org.a.a.t.a c;
    private org.a.a.t.a d;
    private final t e;
    private final t f;
    private org.a.b.m g;
    private byte h[];
    private m i;
    private ac j;
    private byte k[];
    private org.a.g.b l;
    private b m;
    private b n;
    private boolean o;

    ar(z z1, m m1, org.a.b.m m2, ac ac1, org.a.g.b b1)
    {
        b = z1;
        i = m1;
        l = b1;
        boolean flag;
        if (m1 == null)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        o = flag;
        m1 = z1.e();
        if (m1.e())
        {
            a = new aq(org.a.a.n.a(m1.f()).f());
        } else
        {
            m1 = org.a.a.c.h.a(m1.f());
            a = new aq(m1.e(), m1.f().e());
        }
        c = z1.g();
        e = z1.f();
        f = z1.j();
        d = z1.i();
        h = z1.h().f();
        g = m2;
        j = ac1;
    }

    private bd a(be be1, String s)
    {
        b b1;
        b1 = e();
        if (b1 != null && b1.b(be1).a() > 0)
        {
            throw new org.a.b.k((new StringBuilder("The ")).append(s).append(" attribute MUST NOT be an unsigned attribute").toString());
        }
        b1 = d();
        if (b1 != null) goto _L2; else goto _L1
_L1:
        return null;
_L2:
        be1 = b1.b(be1);
        switch (be1.a())
        {
        default:
            throw new org.a.b.k((new StringBuilder("The SignedAttributes in a signerInfo MUST NOT include multiple instances of the ")).append(s).append(" attribute").toString());

        case 0: // '\0'
            break;

        case 1: // '\001'
            be1 = ((a)be1.a(0)).f();
            break; /* Loop/switch isn't completed */
        }
        if (true) goto _L1; else goto _L3
_L3:
        if (be1.f() != 1)
        {
            throw new org.a.b.k((new StringBuilder("A ")).append(s).append(" attribute MUST have a single attribute value").toString());
        } else
        {
            return be1.a(0).c();
        }
    }

    private org.a.a.t.h a(byte abyte0[])
    {
        if (abyte0[0] != 48)
        {
            throw new IOException("not a digest info object");
        }
        org.a.a.t.h h1 = new org.a.a.t.h((r)(new i(abyte0)).c());
        if (h1.a().length != abyte0.length)
        {
            throw new org.a.b.k("malformed RSA signature");
        } else
        {
            return h1;
        }
    }

    private boolean a(PublicKey publickey, Provider provider)
    {
        Object obj;
        Object obj1;
        obj1 = org.a.b.u.a.a(b());
        obj = org.a.b.u.a.c(c());
        obj = (new StringBuilder(String.valueOf(obj1))).append("with").append(((String) (obj))).toString();
        obj = org.a.b.u.a.b(((String) (obj)), provider);
        obj1 = org.a.b.u.a.a(((String) (obj1)), provider);
        if (j == null) goto _L2; else goto _L1
_L1:
        k = j.a();
_L6:
        obj1 = a(((be) (c.a)), "content-type");
        if (obj1 != null)
        {
            break; /* Loop/switch isn't completed */
        }
        if (!o && e != null)
        {
            throw new org.a.b.k("The content-type attribute type MUST be present whenever signed attributes are present in signed-data");
        }
        break MISSING_BLOCK_LABEL_259;
_L2:
        if (g == null) goto _L4; else goto _L3
_L3:
        g.a(new ab(((MessageDigest) (obj1))));
_L8:
        k = ((MessageDigest) (obj1)).digest();
        if (true) goto _L6; else goto _L5
        publickey;
        throw new org.a.b.k("can't process mime object to create signature.", publickey);
_L4:
        if (e != null) goto _L8; else goto _L7
_L7:
        throw new org.a.b.k("data not encapsulated in signature - use detached constructor.");
_L5:
        if (o)
        {
            throw new org.a.b.k("[For counter signatures,] the signedAttributes field MUST NOT contain a content-type attribute");
        }
        if (!(obj1 instanceof be))
        {
            throw new org.a.b.k("content-type attribute value not of ASN.1 type 'OBJECT IDENTIFIER'");
        }
        if (!((be)obj1).equals(i))
        {
            throw new org.a.b.k("content-type attribute value does not match eContentType");
        }
        obj1 = a(((be) (c.b)), "message-digest");
        if (obj1 == null)
        {
            if (e != null)
            {
                throw new org.a.b.k("the message-digest signed attribute type MUST be present when there are any signed attributes present");
            }
        } else
        {
            if (!(obj1 instanceof n))
            {
                throw new org.a.b.k("message-digest attribute value not of ASN.1 type 'OCTET STRING'");
            }
            obj1 = (n)obj1;
            if (!org.a.i.a.b(k, ((n) (obj1)).f()))
            {
                throw new v("message-digest attribute value does not match calculated value");
            }
        }
        obj1 = d();
        if (obj1 != null && ((b) (obj1)).b(c.d).a() > 0)
        {
            throw new org.a.b.k("A countersignature attribute MUST NOT be a signed attribute");
        }
        obj1 = e();
        if (obj1 == null) goto _L10; else goto _L9
_L9:
        int i1;
        obj1 = ((b) (obj1)).b(c.d);
        i1 = 0;
_L16:
        if (i1 < ((e) (obj1)).a()) goto _L11; else goto _L10
_L10:
        ((Signature) (obj)).initVerify(publickey);
        if (e != null) goto _L13; else goto _L12
_L12:
        if (j == null) goto _L15; else goto _L14
_L14:
        boolean flag = a(k, publickey, f(), provider);
        return flag;
_L11:
        if (((a)((e) (obj1)).a(i1)).f().f() < 1)
        {
            throw new org.a.b.k("A countersignature attribute MUST contain at least one AttributeValue");
        }
        i1++;
          goto _L16
_L15:
        if (g != null)
        {
            g.a(new ap(((Signature) (obj))));
        }
_L18:
        return ((Signature) (obj)).verify(f());
_L13:
        ((Signature) (obj)).update(g());
        if (true) goto _L18; else goto _L17
_L17:
        publickey;
        throw new org.a.b.k("key not appropriate to signature in message.", publickey);
        publickey;
        throw new org.a.b.k("can't process mime object to create signature.", publickey);
        publickey;
        throw new org.a.b.k((new StringBuilder("invalid signature format in message: ")).append(publickey.getMessage()).toString(), publickey);
    }

    private boolean a(org.a.a.ar ar1)
    {
        return (ar1 instanceof k) || ar1 == null;
    }

    private boolean a(byte abyte0[], PublicKey publickey, byte abyte1[], Provider provider)
    {
        String s = org.a.b.u.a.c(c());
        if (!s.equals("RSA"))
        {
            break MISSING_BLOCK_LABEL_99;
        }
        provider = org.a.b.g.a.a("RSA/ECB/PKCS1Padding", provider);
        provider.init(2, publickey);
        publickey = a(provider.doFinal(abyte1));
        if (!publickey.e().f().equals(c.f()))
        {
            return false;
        }
        if (a(publickey.e().g()))
        {
            return org.a.i.a.b(abyte0, publickey.f());
        }
        break MISSING_BLOCK_LABEL_228;
        if (s.equals("DSA"))
        {
            provider = org.a.b.u.a.b("NONEwithDSA", provider);
            provider.initVerify(publickey);
            provider.update(abyte0);
            return provider.verify(abyte1);
        } else
        {
            throw new org.a.b.k((new StringBuilder("algorithm: ")).append(s).append(" not supported in base signatures.").toString());
        }
        abyte0;
        throw new org.a.b.k((new StringBuilder("Exception processing signature: ")).append(abyte0).toString(), abyte0);
        abyte0;
        throw new org.a.b.k((new StringBuilder("Exception decoding signature: ")).append(abyte0).toString(), abyte0);
        return false;
    }

    private aa h()
    {
        Object obj = a(c.c, "signing-time");
        if (obj == null)
        {
            return null;
        }
        try
        {
            obj = aa.a(obj);
        }
        catch (IllegalArgumentException illegalargumentexception)
        {
            throw new org.a.b.k("signing-time attribute value not a valid 'Time' structure");
        }
        return ((aa) (obj));
    }

    public aq a()
    {
        return a;
    }

    public boolean a(X509Certificate x509certificate, String s)
    {
        return a(x509certificate, org.a.b.aa.a(s));
    }

    public boolean a(X509Certificate x509certificate, Provider provider)
    {
        aa aa1 = h();
        if (aa1 != null)
        {
            x509certificate.checkValidity(aa1.e());
        }
        return a(x509certificate.getPublicKey(), provider);
    }

    public String b()
    {
        return c.f().e();
    }

    public String c()
    {
        return d.f().e();
    }

    public b d()
    {
        if (e != null && m == null)
        {
            m = new b(e);
        }
        return m;
    }

    public b e()
    {
        if (f != null && n == null)
        {
            n = new b(f);
        }
        return n;
    }

    public byte[] f()
    {
        return (byte[])h.clone();
    }

    public byte[] g()
    {
        if (e != null)
        {
            return e.a("DER");
        } else
        {
            return null;
        }
    }
}
