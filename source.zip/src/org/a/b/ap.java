// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.io.OutputStream;
import java.security.Signature;
import java.security.SignatureException;

// Referenced classes of package org.a.b:
//            w

class ap extends OutputStream
{

    private final Signature a;

    ap(Signature signature)
    {
        a = signature;
    }

    public void write(int i)
    {
        try
        {
            a.update((byte)i);
            return;
        }
        catch (SignatureException signatureexception)
        {
            throw new w((new StringBuilder("signature problem: ")).append(signatureexception).toString(), signatureexception);
        }
    }

    public void write(byte abyte0[], int i, int j)
    {
        try
        {
            a.update(abyte0, i, j);
            return;
        }
        // Misplaced declaration of an exception variable
        catch (byte abyte0[])
        {
            throw new w((new StringBuilder("signature problem: ")).append(abyte0).toString(), abyte0);
        }
    }
}
