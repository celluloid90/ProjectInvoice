// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.io.IOException;
import java.security.AlgorithmParameters;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import org.a.a.k;
import org.a.a.l;
import org.a.a.n;

// Referenced classes of package org.a.b:
//            j, g, k, e, 
//            h

class i
    implements j
{

    final h a;
    private final String b;
    private final Provider c;
    private final l d;
    private final SecretKey e;

    i(h h, String s, Provider provider, l l1, SecretKey secretkey)
    {
        a = h;
        b = s;
        c = provider;
        d = l1;
        e = secretkey;
        super();
    }

    public Object a()
    {
        Cipher cipher;
        cipher = g.a.c(b, c);
        if (d == null || (d instanceof k))
        {
            break MISSING_BLOCK_LABEL_179;
        }
        AlgorithmParameters algorithmparameters = g.a.b(b, cipher.getProvider());
        try
        {
            algorithmparameters.init(d.a(), "ASN.1");
        }
        catch (IOException ioexception)
        {
            try
            {
                throw new org.a.b.k("error decoding algorithm parameters.", ioexception);
            }
            catch (NoSuchAlgorithmException nosuchalgorithmexception)
            {
                if (b.equals(e.a) || b.equals("1.3.6.1.4.1.188.7.1.1.2") || b.equals(e.c) || b.equals(e.d) || b.equals(e.e))
                {
                    cipher.init(2, e, new IvParameterSpec(n.a(d).f()));
                    return cipher;
                } else
                {
                    throw nosuchalgorithmexception;
                }
            }
        }
        cipher.init(2, e, algorithmparameters);
        return cipher;
        if (b.equals(e.a) || b.equals("1.3.6.1.4.1.188.7.1.1.2") || b.equals("1.2.840.113533.7.66.10"))
        {
            cipher.init(2, e, new IvParameterSpec(new byte[8]));
            return cipher;
        } else
        {
            cipher.init(2, e);
            return cipher;
        }
    }
}
