// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.io.IOException;
import java.math.BigInteger;
import java.security.cert.X509CertSelector;
import org.a.a.bf;
import org.a.i.a;
import org.a.i.c;

public class aq extends X509CertSelector
    implements c
{

    private byte a[];
    private org.a.a.s.c b;
    private BigInteger c;

    public aq()
    {
    }

    public aq(org.a.a.s.c c1, BigInteger biginteger)
    {
        b = c1;
        c = biginteger;
        try
        {
            setIssuer(c1.b());
        }
        // Misplaced declaration of an exception variable
        catch (org.a.a.s.c c1)
        {
            throw new IllegalArgumentException((new StringBuilder("invalid issuer: ")).append(c1.getMessage()).toString());
        }
        setSerialNumber(biginteger);
    }

    public aq(byte abyte0[])
    {
        super.setSubjectKeyIdentifier((new bf(abyte0)).b());
        a = abyte0;
    }

    private boolean a(Object obj, Object obj1)
    {
        if (obj != null)
        {
            return obj.equals(obj1);
        }
        return obj1 == null;
    }

    public boolean equals(Object obj)
    {
        if (obj instanceof aq)
        {
            if (org.a.i.a.a(a, ((aq) (obj = (aq)obj)).a) && a(c, ((aq) (obj)).c) && a(b, ((aq) (obj)).b))
            {
                return true;
            }
        }
        return false;
    }

    public int hashCode()
    {
        int j = org.a.i.a.a(a);
        int i = j;
        if (c != null)
        {
            i = j ^ c.hashCode();
        }
        j = i;
        if (b != null)
        {
            j = i ^ b.hashCode();
        }
        return j;
    }
}
