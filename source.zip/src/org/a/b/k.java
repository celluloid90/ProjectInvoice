// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;


public class k extends Exception
{

    Exception a;

    public k(String s)
    {
        super(s);
    }

    public k(String s, Exception exception)
    {
        super(s);
        a = exception;
    }

    public Exception a()
    {
        return a;
    }

    public Throwable getCause()
    {
        return a;
    }
}
