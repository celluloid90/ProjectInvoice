// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.b.a.a;

import android.os.AsyncTask;

public abstract class d extends AsyncTask
{

    public d()
    {
    }

    public transient d a(Object aobj[])
    {
        if (android.os.Build.VERSION.SDK_INT >= 11)
        {
            executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, aobj);
            return this;
        } else
        {
            execute(aobj);
            return this;
        }
    }
}
