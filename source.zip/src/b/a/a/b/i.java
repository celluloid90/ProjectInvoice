// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package b.a.a.b;

import b.a.a.e;

public abstract class i
    implements Cloneable
{

    protected i()
    {
    }

    public abstract double a();

    public abstract double b();

    public abstract double c();

    public Object clone()
    {
        Object obj;
        try
        {
            obj = super.clone();
        }
        catch (CloneNotSupportedException clonenotsupportedexception)
        {
            throw new InternalError();
        }
        return obj;
    }

    public abstract double d();

    public e e()
    {
        int j = (int)Math.floor(f());
        int k = (int)Math.floor(g());
        return new e(j, k, (int)Math.ceil(h()) - j, (int)Math.ceil(i()) - k);
    }

    public double f()
    {
        return a();
    }

    public double g()
    {
        return b();
    }

    public double h()
    {
        return a() + d();
    }

    public double i()
    {
        return b() + c();
    }
}
