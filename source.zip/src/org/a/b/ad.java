// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import org.a.i.a;

// Referenced classes of package org.a.b:
//            am

public class ad extends am
{

    private byte a[];

    public ad(byte abyte0[])
    {
        super(1);
        a = abyte0;
    }

    public boolean equals(Object obj)
    {
        if (!(obj instanceof ad))
        {
            return false;
        } else
        {
            obj = (ad)obj;
            return org.a.i.a.a(a, ((ad) (obj)).a);
        }
    }

    public int hashCode()
    {
        return org.a.i.a.a(a);
    }
}
