// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

// Referenced classes of package org.a.b:
//            ar

public class as
{

    private ArrayList a;
    private Map b;

    public as(Collection collection)
    {
        Iterator iterator;
        a = new ArrayList();
        b = new HashMap();
        iterator = collection.iterator();
_L2:
        ar ar1;
        aq aq;
        if (!iterator.hasNext())
        {
            return;
        }
        ar1 = (ar)iterator.next();
        aq = ar1.a();
        if (b.get(aq) != null)
        {
            break; /* Loop/switch isn't completed */
        }
        b.put(aq, ar1);
_L3:
        a = new ArrayList(collection);
        if (true) goto _L2; else goto _L1
_L1:
        Object obj = b.get(aq);
        if (obj instanceof List)
        {
            ((List)obj).add(ar1);
        } else
        {
            ArrayList arraylist = new ArrayList();
            arraylist.add(obj);
            arraylist.add(ar1);
            b.put(aq, arraylist);
        }
          goto _L3
        if (true) goto _L2; else goto _L4
_L4:
    }

    public Collection a()
    {
        return new ArrayList(a);
    }
}
