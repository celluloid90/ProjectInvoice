// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.b.a;


// Referenced classes of package org.b.a:
//            i, e, a

class c
    implements i
{

    final e a;
    final a b;

    c(a a1, e e1)
    {
        b = a1;
        a = e1;
        super();
    }

    public void a(Object obj)
    {
        a.b(obj);
    }
}
