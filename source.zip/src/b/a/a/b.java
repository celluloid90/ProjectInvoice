// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package b.a.a;

import java.io.Serializable;
import org.apache.harmony.a.a;

public class b extends b.a.a.b.b
    implements Serializable
{

    public int a;
    public int b;

    public b()
    {
        this(0, 0);
    }

    public b(int i, int j)
    {
        a(i, j);
    }

    public void a(int i, int j)
    {
        a = i;
        b = j;
    }

    public boolean equals(Object obj)
    {
        if (obj != this)
        {
            if (obj instanceof b)
            {
                if (((b) (obj = (b)obj)).a != a || ((b) (obj)).b != b)
                {
                    return false;
                }
            } else
            {
                return false;
            }
        }
        return true;
    }

    public int hashCode()
    {
        a a1 = new a();
        a1.a(a);
        a1.a(b);
        return a1.hashCode();
    }

    public String toString()
    {
        return (new StringBuilder(String.valueOf(getClass().getName()))).append("[width=").append(a).append(",height=").append(b).append("]").toString();
    }
}
