// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.io.IOException;
import java.math.BigInteger;
import org.a.a.bf;
import org.a.a.s.c;
import org.a.i.a;

// Referenced classes of package org.a.b:
//            am

public class af extends am
{

    private byte a[];
    private c b;
    private BigInteger c;

    public af(c c1, BigInteger biginteger)
    {
        super(2);
        b = c1;
        c = biginteger;
        try
        {
            setIssuer(c1.b());
        }
        // Misplaced declaration of an exception variable
        catch (c c1)
        {
            throw new IllegalArgumentException((new StringBuilder("invalid issuer: ")).append(c1.getMessage()).toString());
        }
        setSerialNumber(biginteger);
    }

    public af(byte abyte0[])
    {
        super(2);
        super.setSubjectKeyIdentifier((new bf(abyte0)).b());
        a = abyte0;
    }

    private boolean a(Object obj, Object obj1)
    {
        if (obj != null)
        {
            return obj.equals(obj1);
        }
        return obj1 == null;
    }

    public boolean equals(Object obj)
    {
        if (obj instanceof af)
        {
            if (org.a.i.a.a(a, ((af) (obj = (af)obj)).a) && a(c, ((af) (obj)).c) && a(b, ((af) (obj)).b))
            {
                return true;
            }
        }
        return false;
    }

    public int hashCode()
    {
        int j = org.a.i.a.a(a);
        int i = j;
        if (c != null)
        {
            i = j ^ c.hashCode();
        }
        j = i;
        if (b != null)
        {
            j = i ^ b.hashCode();
        }
        return j;
    }
}
