// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package b.a.a.b;

import java.io.Serializable;

public class a
    implements Serializable, Cloneable
{

    double a;
    double b;
    double c;
    double d;
    double e;
    double f;
    transient int g;

    public a()
    {
        g = 0;
        d = 1.0D;
        a = 1.0D;
        f = 0.0D;
        e = 0.0D;
        c = 0.0D;
        b = 0.0D;
    }

    public void a(double ad[])
    {
        ad[0] = a;
        ad[1] = b;
        ad[2] = c;
        ad[3] = d;
        if (ad.length > 4)
        {
            ad[4] = e;
            ad[5] = f;
        }
    }

    public void a(double ad[], int i, double ad1[], int j, int k)
    {
        byte byte1 = 2;
        byte byte0 = byte1;
        int i1 = i;
        int l = j;
        int j1 = k;
        if (ad == ad1)
        {
            byte0 = byte1;
            i1 = i;
            l = j;
            j1 = k;
            if (i < j)
            {
                byte0 = byte1;
                i1 = i;
                l = j;
                j1 = k;
                if (j < k * 2 + i)
                {
                    i1 = (k * 2 + i) - 2;
                    l = (k * 2 + j) - 2;
                    byte0 = -2;
                    j1 = k;
                }
            }
        }
        do
        {
            j1--;
            if (j1 < 0)
            {
                return;
            }
            double d1 = ad[i1 + 0];
            double d2 = ad[i1 + 1];
            ad1[l + 0] = a * d1 + c * d2 + e;
            ad1[l + 1] = d1 * b + d2 * d + f;
            i1 += byte0;
            l += byte0;
        } while (true);
    }

    public void a(float af[], int i, float af1[], int j, int k)
    {
        byte byte1 = 2;
        byte byte0 = byte1;
        int i1 = i;
        int l = j;
        int j1 = k;
        if (af == af1)
        {
            byte0 = byte1;
            i1 = i;
            l = j;
            j1 = k;
            if (i < j)
            {
                byte0 = byte1;
                i1 = i;
                l = j;
                j1 = k;
                if (j < k * 2 + i)
                {
                    i1 = (k * 2 + i) - 2;
                    l = (k * 2 + j) - 2;
                    byte0 = -2;
                    j1 = k;
                }
            }
        }
        do
        {
            j1--;
            if (j1 < 0)
            {
                return;
            }
            float f1 = af[i1 + 0];
            float f2 = af[i1 + 1];
            af1[l + 0] = (float)((double)f1 * a + (double)f2 * c + e);
            af1[l + 1] = (float)((double)f1 * b + (double)f2 * d + f);
            i1 += byte0;
            l += byte0;
        } while (true);
    }

    public Object clone()
    {
        Object obj;
        try
        {
            obj = super.clone();
        }
        catch (CloneNotSupportedException clonenotsupportedexception)
        {
            throw new InternalError();
        }
        return obj;
    }

    public boolean equals(Object obj)
    {
        if (obj != this)
        {
            if (obj instanceof a)
            {
                if (a != ((a) (obj = (a)obj)).a || c != ((a) (obj)).c || e != ((a) (obj)).e || b != ((a) (obj)).b || d != ((a) (obj)).d || f != ((a) (obj)).f)
                {
                    return false;
                }
            } else
            {
                return false;
            }
        }
        return true;
    }

    public int hashCode()
    {
        org.apache.harmony.a.a a1 = new org.apache.harmony.a.a();
        a1.a(a);
        a1.a(c);
        a1.a(e);
        a1.a(b);
        a1.a(d);
        a1.a(f);
        return a1.hashCode();
    }

    public String toString()
    {
        return (new StringBuilder(String.valueOf(getClass().getName()))).append("[[").append(a).append(", ").append(c).append(", ").append(e).append("], [").append(b).append(", ").append(d).append(", ").append(f).append("]]").toString();
    }
}
