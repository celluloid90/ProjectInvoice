// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.io.FilterInputStream;
import java.io.InputStream;
import org.a.i.b.a;

class z extends FilterInputStream
{

    z(InputStream inputstream)
    {
        super(inputstream);
    }

    public int read(byte abyte0[], int i, int j)
    {
        i = a.a(super.in, abyte0, i, j);
        if (i > 0)
        {
            return i;
        } else
        {
            return -1;
        }
    }
}
