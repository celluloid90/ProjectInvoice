// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.a.a.c.e;
import org.a.a.c.x;
import org.a.a.c.z;
import org.a.a.m;
import org.a.a.n;
import org.a.a.t;
import org.a.g.a;

// Referenced classes of package org.a.b:
//            u, n, as, ar, 
//            b, m

public class r
{

    private static final u e;
    x a;
    e b;
    org.a.b.m c;
    as d;
    private Map f;

    public r(e e1)
    {
        b = e1;
        a = x.a(b.f());
        if (a.e().f() != null)
        {
            c = new org.a.b.n(((n)a.e().f()).f());
            return;
        } else
        {
            c = null;
            return;
        }
    }

    public as a()
    {
        if (d != null) goto _L2; else goto _L1
_L1:
        t t1;
        ArrayList arraylist;
        a a1;
        int i;
        t1 = a.f();
        arraylist = new ArrayList();
        a1 = new a();
        i = 0;
_L6:
        if (i != t1.f()) goto _L4; else goto _L3
_L3:
        d = new as(arraylist);
_L2:
        return d;
_L4:
        z z1 = z.a(t1.a(i));
        m m1 = a.e().e();
        if (f == null)
        {
            arraylist.add(new ar(z1, m1, c, null, a1));
        } else
        {
            arraylist.add(new ar(z1, m1, null, new b((byte[])f.get(z1.g().e().e())), a1));
        }
        i++;
        if (true) goto _L6; else goto _L5
_L5:
    }

    public String b()
    {
        return a.e().e().e();
    }

    public org.a.b.m c()
    {
        return c;
    }

    public byte[] d()
    {
        return b.a();
    }

    static 
    {
        e = org.a.b.u.a;
    }
}
