// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.b.a;


// Referenced classes of package org.b.a:
//            a

public abstract class e extends a
{

    public e()
    {
    }

    public final void a(Object obj)
    {
        super.a(obj);
    }

    public final void b(Object obj)
    {
        super.b(obj);
    }

    public final void c(Object obj)
    {
        super.c(obj);
    }
}
