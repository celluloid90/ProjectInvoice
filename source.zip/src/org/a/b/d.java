// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import org.a.a.c.e;
import org.a.a.c.f;
import org.a.a.c.g;
import org.a.a.n;
import org.a.a.t;
import org.a.a.t.a;

// Referenced classes of package org.a.b:
//            n, h, g, aa, 
//            ao

public class d
{

    ao a;
    e b;
    private a c;
    private t d;

    public d(e e1)
    {
        b = e1;
        e1 = g.a(e1.f());
        t t = e1.e();
        Object obj = e1.f();
        c = ((f) (obj)).e();
        obj = new org.a.b.n(((f) (obj)).f().f());
        obj = new h(c, ((p) (obj)));
        a = org.a.b.g.a(t, c, ((q) (obj)));
        d = e1.g();
    }

    public d(byte abyte0[])
    {
        this(org.a.b.aa.a(abyte0));
    }

    public ao a()
    {
        return a;
    }
}
