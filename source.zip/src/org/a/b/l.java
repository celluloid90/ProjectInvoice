// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import javax.crypto.interfaces.PBEKey;

public abstract class l
    implements PBEKey
{

    private char a[];
    private byte b[];
    private int c;

    abstract byte[] a(String s);

    public String getAlgorithm()
    {
        return "PKCS5S2";
    }

    public byte[] getEncoded()
    {
        return null;
    }

    public String getFormat()
    {
        return "RAW";
    }

    public int getIterationCount()
    {
        return c;
    }

    public char[] getPassword()
    {
        return a;
    }

    public byte[] getSalt()
    {
        return b;
    }
}
