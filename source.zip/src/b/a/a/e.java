// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package b.a.a;

import b.a.a.b.g;
import java.io.Serializable;

public class e extends g
    implements Serializable
{

    public int a;
    public int b;
    public int c;
    public int d;

    public e()
    {
        a(0, 0, 0, 0);
    }

    public e(int i, int j, int k, int l)
    {
        a(i, j, k, l);
    }

    public double a()
    {
        return (double)a;
    }

    public void a(int i, int j, int k, int l)
    {
        a = i;
        b = j;
        d = l;
        c = k;
    }

    public double b()
    {
        return (double)b;
    }

    public double c()
    {
        return (double)d;
    }

    public double d()
    {
        return (double)c;
    }

    public e e()
    {
        return new e(a, b, c, d);
    }

    public boolean equals(Object obj)
    {
        if (obj != this)
        {
            if (obj instanceof e)
            {
                if (((e) (obj = (e)obj)).a != a || ((e) (obj)).b != b || ((e) (obj)).c != c || ((e) (obj)).d != d)
                {
                    return false;
                }
            } else
            {
                return false;
            }
        }
        return true;
    }

    public String toString()
    {
        return (new StringBuilder(String.valueOf(getClass().getName()))).append("[x=").append(a).append(",y=").append(b).append(",width=").append(c).append(",height=").append(d).append("]").toString();
    }
}
