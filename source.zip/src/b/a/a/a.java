// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package b.a.a;

import java.io.Serializable;

public class a
    implements Serializable
{

    public static final a BLACK;
    public static final a BLUE;
    public static final a CYAN;
    public static final a DARK_GRAY;
    public static final a GRAY;
    public static final a GREEN;
    public static final a LIGHT_GRAY;
    public static final a MAGENTA;
    private static final int MIN_SCALABLE = 3;
    public static final a ORANGE;
    public static final a PINK;
    public static final a RED;
    private static final double SCALE_FACTOR = 0.69999999999999996D;
    public static final a WHITE;
    public static final a YELLOW;
    public static final a black;
    public static final a blue;
    public static final a cyan;
    public static final a darkGray;
    public static final a gray;
    public static final a green;
    public static final a lightGray;
    public static final a magenta;
    public static final a orange;
    public static final a pink;
    public static final a red;
    private static final long serialVersionUID = 0x1a51783108f3375L;
    public static final a white;
    public static final a yellow;
    private float falpha;
    private float frgbvalue[];
    private float fvalue[];
    int value;

    public a(float f, float f1, float f2)
    {
        this(f, f1, f2, 1.0F);
    }

    public a(float f, float f1, float f2, float f3)
    {
        this((int)((double)(f * 255F) + 0.5D), (int)((double)(f1 * 255F) + 0.5D), (int)((double)(f2 * 255F) + 0.5D), (int)((double)(f3 * 255F) + 0.5D));
        falpha = f3;
        fvalue = new float[3];
        fvalue[0] = f;
        fvalue[1] = f1;
        fvalue[2] = f2;
        frgbvalue = fvalue;
    }

    public a(int i)
    {
        value = 0xff000000 | i;
    }

    public a(int i, int j, int k)
    {
        if ((i & 0xff) != i || (j & 0xff) != j || (k & 0xff) != k)
        {
            throw new IllegalArgumentException(org.apache.harmony.awt.a.a.a.a("awt.109"));
        } else
        {
            value = j << 8 | k | i << 16 | 0xff000000;
            return;
        }
    }

    public a(int i, int j, int k, int l)
    {
        if ((i & 0xff) != i || (j & 0xff) != j || (k & 0xff) != k || (l & 0xff) != l)
        {
            throw new IllegalArgumentException(org.apache.harmony.awt.a.a.a.a("awt.109"));
        } else
        {
            value = j << 8 | k | i << 16 | l << 24;
            return;
        }
    }

    public a(int i, boolean flag)
    {
        if (!flag)
        {
            value = 0xff000000 | i;
            return;
        } else
        {
            value = i;
            return;
        }
    }

    public static int HSBtoRGB(float f, float f1, float f2)
    {
        if (f1 != 0.0F) goto _L2; else goto _L1
_L1:
        f1 = f2;
        f = f2;
_L4:
        int i = (int)((double)f * 255D + 0.5D);
        return (int)((double)f1 * 255D + 0.5D) << 8 | i << 16 | (int)((double)f2 * 255D + 0.5D) | 0xff000000;
_L2:
        f = (f - (float)Math.floor(f)) * 6F;
        int j = (int)Math.floor(f);
        float f4 = f - (float)j;
        f = (1.0F - f1) * f2;
        float f3 = (1.0F - f1 * f4) * f2;
        f1 = (1.0F - (1.0F - f4) * f1) * f2;
        switch (j)
        {
        default:
            f2 = 0.0F;
            f1 = 0.0F;
            f = 0.0F;
            break;

        case 0: // '\0'
            f3 = f;
            f = f2;
            f2 = f3;
            break;

        case 1: // '\001'
            f1 = f2;
            f2 = f;
            f = f3;
            break;

        case 2: // '\002'
            f3 = f2;
            f2 = f1;
            f1 = f3;
            break;

        case 3: // '\003'
            f1 = f3;
            break;

        case 4: // '\004'
            f3 = f1;
            f1 = f;
            f = f3;
            break;

        case 5: // '\005'
            f1 = f;
            f = f2;
            f2 = f3;
            break;
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    public static float[] RGBtoHSB(int i, int j, int k, float af[])
    {
        float f;
        float f3;
        float af1[];
        int l;
        int i1;
        f = 0.0F;
        af1 = af;
        if (af == null)
        {
            af1 = new float[3];
        }
        l = Math.max(k, Math.max(i, j));
        i1 = Math.min(k, Math.min(i, j));
        f3 = (float)l / 255F;
        if (l != i1) goto _L2; else goto _L1
_L1:
        float f1 = 0.0F;
_L5:
        af1[0] = f1;
        af1[1] = f;
        af1[2] = f3;
        return af1;
_L2:
        float f2;
        float f4;
        f1 = (float)(l - i1) / (float)l;
        f = (float)(l - i) / (float)(l - i1);
        f2 = (float)(l - j) / (float)(l - i1);
        f4 = (float)(l - k) / (float)(l - i1);
        if (i != l) goto _L4; else goto _L3
_L3:
        f = f4 - f2;
_L6:
        f2 = f / 6F;
        if (f2 < 0.0F)
        {
            f2 = 1.0F + f2;
            f = f1;
            f1 = f2;
        } else
        {
            f = f1;
            f1 = f2;
        }
        if (true) goto _L5; else goto _L4
_L4:
        if (j == l)
        {
            f = (2.0F + f) - f4;
        } else
        {
            f = (4F + f2) - f;
        }
          goto _L6
    }

    public static a decode(String s)
    {
        return new a(Integer.decode(s).intValue());
    }

    public static a getColor(String s)
    {
        s = Integer.getInteger(s);
        if (s == null)
        {
            return null;
        } else
        {
            return new a(s.intValue());
        }
    }

    public static a getColor(String s, int i)
    {
        s = Integer.getInteger(s);
        if (s == null)
        {
            return new a(i);
        } else
        {
            return new a(s.intValue());
        }
    }

    public static a getColor(String s, a a1)
    {
        s = Integer.getInteger(s);
        if (s == null)
        {
            return a1;
        } else
        {
            return new a(s.intValue());
        }
    }

    public static a getHSBColor(float f, float f1, float f2)
    {
        return new a(HSBtoRGB(f, f1, f2));
    }

    public a brighter()
    {
        int i;
        char c;
        int l;
        c = '\377';
        i = getRed();
        int k = getBlue();
        l = getGreen();
        if (i == 0 && k == 0 && l == 0)
        {
            return new a(3, 3, 3);
        }
        int j;
        if (i < 3 && i != 0)
        {
            j = 3;
        } else
        {
            j = (int)((double)i / 0.69999999999999996D);
            i = j;
            if (j > 255)
            {
                i = 255;
            }
            j = i;
        }
        if (k < 3 && k != 0)
        {
            k = 3;
        } else
        {
            k = (int)((double)k / 0.69999999999999996D);
            i = k;
            if (k > 255)
            {
                i = 255;
            }
            k = i;
        }
        if (l >= 3 || l == 0) goto _L2; else goto _L1
_L1:
        i = 3;
_L4:
        return new a(j, i, k);
_L2:
        l = (int)((double)l / 0.69999999999999996D);
        i = c;
        if (l <= 255)
        {
            i = l;
        }
        if (true) goto _L4; else goto _L3
_L3:
    }

    public a darker()
    {
        return new a((int)((double)getRed() * 0.69999999999999996D), (int)((double)getGreen() * 0.69999999999999996D), (int)((double)getBlue() * 0.69999999999999996D));
    }

    public boolean equals(Object obj)
    {
        boolean flag1 = false;
        boolean flag = flag1;
        if (obj instanceof a)
        {
            flag = flag1;
            if (((a)obj).value == value)
            {
                flag = true;
            }
        }
        return flag;
    }

    public int getAlpha()
    {
        return value >> 24 & 0xff;
    }

    public int getBlue()
    {
        return value & 0xff;
    }

    public float[] getColorComponents(float af[])
    {
        if (fvalue != null) goto _L2; else goto _L1
_L1:
        af = getRGBColorComponents(af);
_L4:
        return af;
_L2:
        float af1[] = af;
        if (af == null)
        {
            af1 = new float[fvalue.length];
        }
        int i = 0;
        do
        {
            af = af1;
            if (i >= fvalue.length)
            {
                continue;
            }
            af1[i] = fvalue[i];
            i++;
        } while (true);
        if (true) goto _L4; else goto _L3
_L3:
    }

    public float[] getComponents(float af[])
    {
        if (fvalue == null)
        {
            return getRGBComponents(af);
        }
        int i = fvalue.length;
        float af1[] = af;
        if (af == null)
        {
            af1 = new float[i + 1];
        }
        getColorComponents(af1);
        af1[i] = falpha;
        return af1;
    }

    public int getGreen()
    {
        return value >> 8 & 0xff;
    }

    public int getRGB()
    {
        return value;
    }

    public float[] getRGBColorComponents(float af[])
    {
        float af1[] = af;
        if (af == null)
        {
            af1 = new float[3];
        }
        if (frgbvalue != null)
        {
            af1[2] = frgbvalue[2];
            af1[1] = frgbvalue[1];
            af1[0] = frgbvalue[0];
            return af1;
        } else
        {
            af1[2] = (float)getBlue() / 255F;
            af1[1] = (float)getGreen() / 255F;
            af1[0] = (float)getRed() / 255F;
            return af1;
        }
    }

    public float[] getRGBComponents(float af[])
    {
        float af1[] = af;
        if (af == null)
        {
            af1 = new float[4];
        }
        if (frgbvalue != null)
        {
            af1[3] = falpha;
        } else
        {
            af1[3] = (float)getAlpha() / 255F;
        }
        getRGBColorComponents(af1);
        return af1;
    }

    public int getRed()
    {
        return value >> 16 & 0xff;
    }

    public int getTransparency()
    {
        switch (getAlpha())
        {
        default:
            return 3;

        case 255: 
            return 1;

        case 0: // '\0'
            return 2;
        }
    }

    public int hashCode()
    {
        return value;
    }

    public String toString()
    {
        return (new StringBuilder(String.valueOf(getClass().getName()))).append("[r=").append(getRed()).append(",g=").append(getGreen()).append(",b=").append(getBlue()).append("]").toString();
    }

    static 
    {
        white = new a(255, 255, 255);
        WHITE = white;
        lightGray = new a(192, 192, 192);
        LIGHT_GRAY = lightGray;
        gray = new a(128, 128, 128);
        GRAY = gray;
        darkGray = new a(64, 64, 64);
        DARK_GRAY = darkGray;
        black = new a(0, 0, 0);
        BLACK = black;
        red = new a(255, 0, 0);
        RED = red;
        pink = new a(255, 175, 175);
        PINK = pink;
        orange = new a(255, 200, 0);
        ORANGE = orange;
        yellow = new a(255, 255, 0);
        YELLOW = yellow;
        green = new a(0, 255, 0);
        GREEN = green;
        magenta = new a(255, 0, 255);
        MAGENTA = magenta;
        cyan = new a(0, 255, 255);
        CYAN = cyan;
        blue = new a(0, 0, 255);
        BLUE = blue;
    }
}
