// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.io.IOException;
import java.io.InputStream;
import java.security.NoSuchProviderException;
import java.security.Provider;
import java.security.Security;
import org.a.a.c.e;
import org.a.a.i;
import org.a.i.b.a;

// Referenced classes of package org.a.b:
//            k

class aa
{

    private static final Runtime a = Runtime.getRuntime();

    public static Provider a(String s)
    {
        if (s != null)
        {
            Provider provider = Security.getProvider(s);
            if (provider != null)
            {
                return provider;
            } else
            {
                throw new NoSuchProviderException((new StringBuilder("provider ")).append(s).append(" not found.").toString());
            }
        } else
        {
            return null;
        }
    }

    private static e a(i j)
    {
        try
        {
            j = e.a(j.c());
        }
        // Misplaced declaration of an exception variable
        catch (i j)
        {
            throw new k("IOException reading content.", j);
        }
        // Misplaced declaration of an exception variable
        catch (i j)
        {
            throw new k("Malformed content.", j);
        }
        // Misplaced declaration of an exception variable
        catch (i j)
        {
            throw new k("Malformed content.", j);
        }
        return j;
    }

    static e a(byte abyte0[])
    {
        return a(new i(abyte0));
    }

    public static byte[] a(InputStream inputstream)
    {
        return org.a.i.b.a.a(inputstream);
    }

}
