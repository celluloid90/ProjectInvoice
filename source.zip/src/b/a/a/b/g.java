// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package b.a.a.b;

import org.apache.harmony.a.a;

// Referenced classes of package b.a.a.b:
//            i, c

public abstract class g extends i
{

    protected g()
    {
    }

    public boolean a(double d, double d1, double d2, double d3)
    {
        double d4 = a();
        double d5 = b();
        double d6 = d() + d4;
        double d7 = c() + d5;
        return d4 <= d && d <= d6 && d5 <= d1 && d1 <= d7 || d4 <= d2 && d2 <= d6 && d5 <= d3 && d3 <= d7 || b.a.a.b.c.a(d4, d5, d6, d7, d, d1, d2, d3) || b.a.a.b.c.a(d6, d5, d4, d7, d, d1, d2, d3);
    }

    public boolean equals(Object obj)
    {
        if (obj != this)
        {
            if (obj instanceof g)
            {
                if (a() != ((g) (obj = (g)obj)).a() || b() != ((g) (obj)).b() || d() != ((g) (obj)).d() || c() != ((g) (obj)).c())
                {
                    return false;
                }
            } else
            {
                return false;
            }
        }
        return true;
    }

    public int hashCode()
    {
        a a1 = new a();
        a1.a(a());
        a1.a(b());
        a1.a(d());
        a1.a(c());
        return a1.hashCode();
    }
}
