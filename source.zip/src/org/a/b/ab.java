// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.io.OutputStream;
import java.security.MessageDigest;

class ab extends OutputStream
{

    private final MessageDigest a;

    ab(MessageDigest messagedigest)
    {
        a = messagedigest;
    }

    public void write(int i)
    {
        a.update((byte)i);
    }

    public void write(byte abyte0[], int i, int j)
    {
        a.update(abyte0, i, j);
    }
}
