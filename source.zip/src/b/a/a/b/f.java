// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package b.a.a.b;

import org.apache.harmony.a.a;

public abstract class f
    implements Cloneable
{

    protected f()
    {
    }

    public abstract double a();

    public abstract double b();

    public Object clone()
    {
        Object obj;
        try
        {
            obj = super.clone();
        }
        catch (CloneNotSupportedException clonenotsupportedexception)
        {
            throw new InternalError();
        }
        return obj;
    }

    public boolean equals(Object obj)
    {
        if (obj != this)
        {
            if (obj instanceof f)
            {
                if (a() != ((f) (obj = (f)obj)).a() || b() != ((f) (obj)).b())
                {
                    return false;
                }
            } else
            {
                return false;
            }
        }
        return true;
    }

    public int hashCode()
    {
        a a1 = new a();
        a1.a(a());
        a1.a(b());
        return a1.hashCode();
    }
}
