// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.io.IOException;
import java.security.Provider;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.SecretKey;
import org.a.a.be;
import org.a.a.l;
import org.a.a.t.a;

// Referenced classes of package org.a.b:
//            q, i, g, o, 
//            p, k

class h
    implements q
{

    private a a;
    private Cipher b;
    private p c;

    h(a a1, p p1)
    {
        a = a1;
        c = p1;
    }

    public a a()
    {
        return a;
    }

    public p a(SecretKey secretkey, Provider provider)
    {
        b = (Cipher)org.a.b.g.a(new i(this, a.f().e(), provider, (l)a.g(), secretkey));
        try
        {
            secretkey = new o(new CipherInputStream(c.a(), b));
        }
        // Misplaced declaration of an exception variable
        catch (SecretKey secretkey)
        {
            throw new k("error reading content.", secretkey);
        }
        return secretkey;
    }
}
