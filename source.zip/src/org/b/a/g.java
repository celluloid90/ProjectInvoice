// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.b.a;


// Referenced classes of package org.b.a:
//            d, e, i, j

public interface g
{

    public abstract g a(d d);

    public abstract g a(e e);

    public abstract g a(i i);

    public abstract g a(j j);

    public abstract g b(j j);

    public abstract boolean c();
}
