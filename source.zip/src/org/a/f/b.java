// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.f;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.cert.X509Certificate;
import org.a.a.ap;
import org.a.a.ba;
import org.a.a.bb;
import org.a.a.bd;
import org.a.a.be;
import org.a.a.bf;
import org.a.a.i;
import org.a.a.m;
import org.a.a.t.a;
import org.a.a.t.u;
import org.a.d.d;

// Referenced classes of package org.a.f:
//            i, d

public class b
{

    private final org.a.a.l.b a;

    public b(String s, X509Certificate x509certificate, BigInteger biginteger)
    {
        this(s, x509certificate, biginteger, "BC");
    }

    public b(String s, X509Certificate x509certificate, BigInteger biginteger, String s1)
    {
        a = a(new a(new be(s), bb.a), x509certificate, new ba(biginteger), s1);
    }

    public b(org.a.a.l.b b1)
    {
        if (b1 == null)
        {
            throw new IllegalArgumentException("'id' cannot be null");
        } else
        {
            a = b1;
            return;
        }
    }

    private static org.a.a.l.b a(a a1, X509Certificate x509certificate, ba ba1, String s)
    {
        try
        {
            s = org.a.f.i.a(a1.e().e(), s);
            s.update(org.a.d.b.b(x509certificate).a());
            bf bf1 = new bf(s.digest());
            s.update(u.a((new i(x509certificate.getPublicKey().getEncoded())).c()).g().e());
            a1 = new org.a.a.l.b(a1, bf1, new bf(s.digest()), ba1);
        }
        // Misplaced declaration of an exception variable
        catch (a a1)
        {
            throw new org.a.f.d((new StringBuilder("problem creating ID: ")).append(a1).toString(), a1);
        }
        return a1;
    }

    public org.a.a.l.b a()
    {
        return a;
    }

    public boolean equals(Object obj)
    {
        if (!(obj instanceof b))
        {
            return false;
        } else
        {
            obj = (b)obj;
            return a.c().equals(((b) (obj)).a.c());
        }
    }

    public int hashCode()
    {
        return a.c().hashCode();
    }
}
