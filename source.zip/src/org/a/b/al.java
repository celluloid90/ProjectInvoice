// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.a.a.be;
import org.a.a.c.s;
import org.a.a.n;
import org.a.a.r;
import org.a.a.t.a;

// Referenced classes of package org.a.b:
//            an, c, ak, g, 
//            l, k, q, a, 
//            y

public class al extends an
{

    static Map a;
    static Map b;
    private s f;

    al(s s1, a a1, q q, org.a.b.a a2)
    {
        super(s1.f(), a1, q, a2);
        f = s1;
        c = new ak();
    }

    public y a(Key key, Provider provider)
    {
        try
        {
            Object obj1 = org.a.b.g.a;
            Object obj = (r)org.a.a.t.a.a(f.f()).g();
            String s1 = be.a(((r) (obj)).a(0)).e();
            obj1 = ((g) (obj1)).c(((g) (obj1)).b(s1), provider);
            obj = new IvParameterSpec(n.a(((r) (obj)).a(1)).f());
            ((Cipher) (obj1)).init(4, new SecretKeySpec(((l)key).a(s1), s1), ((java.security.spec.AlgorithmParameterSpec) (obj)));
            key = c(((Cipher) (obj1)).unwrap(f.g().f(), a(), 3), provider);
        }
        // Misplaced declaration of an exception variable
        catch (Key key)
        {
            throw new k("can't find algorithm.", key);
        }
        // Misplaced declaration of an exception variable
        catch (Key key)
        {
            throw new k("key invalid in message.", key);
        }
        // Misplaced declaration of an exception variable
        catch (Key key)
        {
            throw new k("required padding not supported.", key);
        }
        // Misplaced declaration of an exception variable
        catch (Key key)
        {
            throw new k("invalid iv.", key);
        }
        return key;
    }

    static 
    {
        a = new HashMap();
        b = new HashMap();
        b.put(org.a.b.c.a, new Integer(8));
        b.put(c.e, new Integer(16));
        b.put(c.f, new Integer(16));
        b.put(c.g, new Integer(16));
        a.put(org.a.b.c.a, new Integer(192));
        a.put(c.e, new Integer(128));
        a.put(c.f, new Integer(192));
        a.put(c.g, new Integer(256));
    }
}
