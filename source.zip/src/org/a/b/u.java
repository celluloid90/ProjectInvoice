// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import java.security.Signature;
import java.util.HashMap;
import java.util.Map;
import org.a.a.be;
import org.a.a.e.a;
import org.a.a.j.b;
import org.a.a.m;
import org.a.a.n.c;
import org.a.a.p.p;
import org.a.a.t.ag;
import org.a.a.u.ai;

// Referenced classes of package org.a.b:
//            s

class u
{

    static final u a = new u();
    private static final Map b;
    private static final Map c;
    private static final Map d;

    u()
    {
    }

    private static void a(be be1, String s1, String s2)
    {
        c.put(be1.e(), s1);
        b.put(be1.e(), s2);
    }

    private MessageDigest c(String s1, Provider provider)
    {
        if (provider != null)
        {
            return MessageDigest.getInstance(s1, provider);
        } else
        {
            return MessageDigest.getInstance(s1);
        }
    }

    String a(String s1)
    {
        String s2 = (String)c.get(s1);
        if (s2 != null)
        {
            return s2;
        } else
        {
            return s1;
        }
    }

    MessageDigest a(String s1, Provider provider)
    {
        MessageDigest messagedigest = c(s1, provider);
        return messagedigest;
        NoSuchAlgorithmException nosuchalgorithmexception;
        nosuchalgorithmexception;
        String as[];
        int i;
        as = b(s1);
        i = 0;
_L1:
        MessageDigest messagedigest1;
        NoSuchAlgorithmException nosuchalgorithmexception1;
        if (i == as.length)
        {
            if (provider != null)
            {
                return a(s1, null);
            } else
            {
                throw nosuchalgorithmexception;
            }
        }
        messagedigest1 = c(as[i], provider);
        return messagedigest1;
        nosuchalgorithmexception1;
        i++;
          goto _L1
    }

    Signature b(String s1, Provider provider)
    {
        if (provider != null)
        {
            return Signature.getInstance(s1, provider);
        } else
        {
            return Signature.getInstance(s1);
        }
    }

    String[] b(String s1)
    {
        s1 = (String[])d.get(s1);
        if (s1 != null)
        {
            return s1;
        } else
        {
            return new String[0];
        }
    }

    String c(String s1)
    {
        String s2 = (String)b.get(s1);
        if (s2 != null)
        {
            return s2;
        } else
        {
            return s1;
        }
    }

    static 
    {
        b = new HashMap();
        c = new HashMap();
        d = new HashMap();
        a(b.C, "SHA224", "DSA");
        a(b.D, "SHA256", "DSA");
        a(b.E, "SHA384", "DSA");
        a(b.F, "SHA512", "DSA");
        a(org.a.a.m.b.j, "SHA1", "DSA");
        a(org.a.a.m.b.a, "MD4", "RSA");
        a(org.a.a.m.b.c, "MD4", "RSA");
        a(org.a.a.m.b.b, "MD5", "RSA");
        a(org.a.a.m.b.k, "SHA1", "RSA");
        a(c.i_, "MD2", "RSA");
        a(c.d, "MD4", "RSA");
        a(c.e, "MD5", "RSA");
        a(c.j_, "SHA1", "RSA");
        a(c.p_, "SHA224", "RSA");
        a(c.m_, "SHA256", "RSA");
        a(c.n_, "SHA384", "RSA");
        a(c.o_, "SHA512", "RSA");
        a(ai.i, "SHA1", "ECDSA");
        a(ai.m, "SHA224", "ECDSA");
        a(ai.n, "SHA256", "ECDSA");
        a(ai.o, "SHA384", "ECDSA");
        a(ai.p, "SHA512", "ECDSA");
        a(ai.V, "SHA1", "DSA");
        a(a.q, "SHA1", "ECDSA");
        a(a.r, "SHA224", "ECDSA");
        a(a.s, "SHA256", "ECDSA");
        a(a.t, "SHA384", "ECDSA");
        a(a.u, "SHA512", "ECDSA");
        a(a.l, "SHA1", "RSA");
        a(a.m, "SHA256", "RSA");
        a(a.n, "SHA1", "RSAandMGF1");
        a(a.o, "SHA256", "RSAandMGF1");
        b.put(ai.U.e(), "DSA");
        b.put(c.h_.e(), "RSA");
        b.put(p.e, "RSA");
        b.put(ag.l.e(), "RSA");
        b.put(s.o, "RSAandMGF1");
        b.put(org.a.a.d.a.c.e(), "GOST3410");
        b.put(org.a.a.d.a.d.e(), "ECGOST3410");
        b.put("1.3.6.1.4.1.5849.1.6.2", "ECGOST3410");
        b.put("1.3.6.1.4.1.5849.1.1.5", "GOST3410");
        b.put(org.a.a.d.a.f.e(), "ECGOST3410");
        b.put(org.a.a.d.a.e.e(), "GOST3410");
        c.put(c.E.e(), "MD2");
        c.put(c.F.e(), "MD4");
        c.put(c.G.e(), "MD5");
        c.put(org.a.a.m.b.i.e(), "SHA1");
        c.put(b.e.e(), "SHA224");
        c.put(b.b.e(), "SHA256");
        c.put(b.c.e(), "SHA384");
        c.put(b.d.e(), "SHA512");
        c.put(p.c.e(), "RIPEMD128");
        c.put(p.b.e(), "RIPEMD160");
        c.put(p.d.e(), "RIPEMD256");
        c.put(org.a.a.d.a.a.e(), "GOST3411");
        c.put("1.3.6.1.4.1.5849.1.2.1", "GOST3411");
        d.put("SHA1", new String[] {
            "SHA-1"
        });
        d.put("SHA224", new String[] {
            "SHA-224"
        });
        d.put("SHA256", new String[] {
            "SHA-256"
        });
        d.put("SHA384", new String[] {
            "SHA-384"
        });
        d.put("SHA512", new String[] {
            "SHA-512"
        });
    }
}
