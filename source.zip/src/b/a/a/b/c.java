// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package b.a.a.b;


// Referenced classes of package b.a.a.b:
//            g

public abstract class c
    implements Cloneable
{

    protected c()
    {
    }

    public static boolean a(double d1, double d2, double d3, double d4, 
            double d5, double d6, double d7, double d8)
    {
        d3 -= d1;
        d4 -= d2;
        d5 -= d1;
        d6 -= d2;
        d1 = d7 - d1;
        d8 -= d2;
        d2 = d3 * d6 - d5 * d4;
        d7 = d3 * d8 - d1 * d4;
        if (d2 == 0.0D && d7 == 0.0D)
        {
            if (d3 != 0.0D)
            {
                return d1 * d5 <= 0.0D || d5 * d3 >= 0.0D && (d3 <= 0.0D ? d5 >= d3 || d1 >= d3 : d5 <= d3 || d1 <= d3);
            }
            if (d4 != 0.0D)
            {
                return d8 * d6 <= 0.0D || d6 * d4 >= 0.0D && (d4 <= 0.0D ? d6 >= d4 || d8 >= d4 : d6 <= d4 || d8 <= d4);
            } else
            {
                return false;
            }
        }
        d1 = d5 * d8 - d1 * d6;
        return d2 * d7 <= 0.0D && d1 * ((d2 + d1) - d7) <= 0.0D;
    }

    public abstract double a();

    public abstract void a(double d1, double d2, double d3, double d4);

    public boolean a(g g1)
    {
        return g1.a(a(), b(), c(), d());
    }

    public abstract double b();

    public abstract double c();

    public Object clone()
    {
        Object obj;
        try
        {
            obj = super.clone();
        }
        catch (CloneNotSupportedException clonenotsupportedexception)
        {
            throw new InternalError();
        }
        return obj;
    }

    public abstract double d();
}
