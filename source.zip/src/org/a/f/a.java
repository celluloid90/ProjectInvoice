// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.f;

import java.security.NoSuchProviderException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.cert.X509Certificate;
import java.security.cert.X509Extension;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;
import org.a.a.ap;
import org.a.a.be;
import org.a.a.l.k;
import org.a.a.l.n;
import org.a.a.r;
import org.a.a.t.ac;
import org.a.a.t.ad;

// Referenced classes of package org.a.f:
//            i, d, k

public class a
    implements X509Extension
{

    org.a.a.l.a a;
    k b;
    X509Certificate c[];

    public a(org.a.a.l.a a1)
    {
        c = null;
        a = a1;
        b = a1.e();
    }

    private Set a(boolean flag)
    {
        HashSet hashset;
        ad ad1;
        hashset = new HashSet();
        ad1 = b();
        if (ad1 == null) goto _L2; else goto _L1
_L1:
        Enumeration enumeration = ad1.e();
_L5:
        if (enumeration.hasMoreElements()) goto _L3; else goto _L2
_L2:
        return hashset;
_L3:
        be be1 = (be)enumeration.nextElement();
        if (flag == ad1.a(be1).a())
        {
            hashset.add(be1.e());
        }
        if (true) goto _L5; else goto _L4
_L4:
    }

    public boolean a(PublicKey publickey, String s)
    {
        boolean flag;
        try
        {
            s = i.b(c(), s);
            s.initVerify(publickey);
            s.update(a.e().a("DER"));
            flag = s.verify(d());
        }
        // Misplaced declaration of an exception variable
        catch (PublicKey publickey)
        {
            throw publickey;
        }
        // Misplaced declaration of an exception variable
        catch (PublicKey publickey)
        {
            throw new d((new StringBuilder("exception processing sig: ")).append(publickey).toString(), publickey);
        }
        return flag;
    }

    public org.a.f.k[] a()
    {
        r r1 = b.e();
        org.a.f.k ak[] = new org.a.f.k[r1.f()];
        int j = 0;
        do
        {
            if (j == ak.length)
            {
                return ak;
            }
            ak[j] = new org.a.f.k(n.a(r1.a(j)));
            j++;
        } while (true);
    }

    public ad b()
    {
        return b.f();
    }

    public String c()
    {
        return i.a(a.f().f());
    }

    public byte[] d()
    {
        return a.g().e();
    }

    public byte[] e()
    {
        return a.a();
    }

    public boolean equals(Object obj)
    {
        if (obj == this)
        {
            return true;
        }
        if (!(obj instanceof a))
        {
            return false;
        } else
        {
            obj = (a)obj;
            return a.equals(((a) (obj)).a);
        }
    }

    public Set getCriticalExtensionOIDs()
    {
        return a(true);
    }

    public byte[] getExtensionValue(String s)
    {
        ad ad1 = b();
        if (ad1 != null)
        {
            s = ad1.a(new be(s));
            if (s != null)
            {
                try
                {
                    s = s.b().a("DER");
                }
                // Misplaced declaration of an exception variable
                catch (String s)
                {
                    throw new RuntimeException((new StringBuilder("error encoding ")).append(s.toString()).toString());
                }
                return s;
            }
        }
        return null;
    }

    public Set getNonCriticalExtensionOIDs()
    {
        return a(false);
    }

    public boolean hasUnsupportedCriticalExtension()
    {
        Set set = getCriticalExtensionOIDs();
        return set != null && !set.isEmpty();
    }

    public int hashCode()
    {
        return a.hashCode();
    }
}
