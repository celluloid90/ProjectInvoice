// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.io.IOException;
import java.math.BigInteger;
import org.a.a.bf;
import org.a.a.s.c;
import org.a.i.a;

// Referenced classes of package org.a.b:
//            am

public class ah extends am
{

    private byte a[];
    private c b;
    private BigInteger c;

    public ah(c c1, BigInteger biginteger)
    {
        super(0);
        b = c1;
        c = biginteger;
        try
        {
            setIssuer(c1.b());
        }
        // Misplaced declaration of an exception variable
        catch (c c1)
        {
            throw new IllegalArgumentException((new StringBuilder("invalid issuer: ")).append(c1.getMessage()).toString());
        }
        setSerialNumber(biginteger);
    }

    public ah(byte abyte0[])
    {
        super(0);
        super.setSubjectKeyIdentifier((new bf(abyte0)).b());
        a = abyte0;
    }

    private boolean a(Object obj, Object obj1)
    {
        if (obj != null)
        {
            return obj.equals(obj1);
        }
        return obj1 == null;
    }

    public boolean equals(Object obj)
    {
        if (obj instanceof ah)
        {
            if (org.a.i.a.a(a, ((ah) (obj = (ah)obj)).a) && a(c, ((ah) (obj)).c) && a(b, ((ah) (obj)).b))
            {
                return true;
            }
        }
        return false;
    }

    public int hashCode()
    {
        int j = org.a.i.a.a(a);
        int i = j;
        if (c != null)
        {
            i = j ^ c.hashCode();
        }
        j = i;
        if (b != null)
        {
            j = i ^ b.hashCode();
        }
        return j;
    }
}
