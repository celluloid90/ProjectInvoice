// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.b.a;


// Referenced classes of package org.b.a:
//            j, e, a

class b
    implements j
{

    final e a;
    final a b;

    b(a a1, e e1)
    {
        b = a1;
        a = e1;
        super();
    }

    public void a(Object obj)
    {
        a.a(obj);
    }
}
