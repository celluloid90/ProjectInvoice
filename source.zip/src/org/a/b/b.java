// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import org.a.i.a;

// Referenced classes of package org.a.b:
//            ac

class b
    implements ac
{

    private final byte a[];

    b(byte abyte0[])
    {
        a = abyte0;
    }

    public byte[] a()
    {
        return org.a.i.a.b(a);
    }
}
