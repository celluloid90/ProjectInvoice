// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package b.a.a.b;


// Referenced classes of package b.a.a.b:
//            c

public class d extends c
{

    public double a;
    public double b;
    public double c;
    public double d;

    public d()
    {
    }

    public d(double d1, double d2, double d3, double d4)
    {
        a(d1, d2, d3, d4);
    }

    public double a()
    {
        return a;
    }

    public void a(double d1, double d2, double d3, double d4)
    {
        a = d1;
        b = d2;
        c = d3;
        d = d4;
    }

    public double b()
    {
        return b;
    }

    public double c()
    {
        return c;
    }

    public double d()
    {
        return d;
    }
}
