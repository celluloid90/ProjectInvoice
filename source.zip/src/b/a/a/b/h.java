// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package b.a.a.b;


// Referenced classes of package b.a.a.b:
//            g

public class h extends g
{

    public double a;
    public double b;
    public double c;
    public double d;

    public h()
    {
    }

    public h(double d1, double d2, double d3, double d4)
    {
        b(d1, d2, d3, d4);
    }

    public double a()
    {
        return a;
    }

    public double b()
    {
        return b;
    }

    public void b(double d1, double d2, double d3, double d4)
    {
        a = d1;
        b = d2;
        c = d3;
        d = d4;
    }

    public double c()
    {
        return d;
    }

    public double d()
    {
        return c;
    }

    public String toString()
    {
        return (new StringBuilder(String.valueOf(getClass().getName()))).append("[x=").append(a).append(",y=").append(b).append(",width=").append(c).append(",height=").append(d).append("]").toString();
    }
}
