// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.math.BigInteger;
import java.security.cert.X509CertSelector;
import org.a.i.a;

class aj extends X509CertSelector
{

    aj()
    {
    }

    private boolean a(Object obj, Object obj1)
    {
        if (obj != null)
        {
            return obj.equals(obj1);
        }
        return obj1 == null;
    }

    public boolean equals(Object obj)
    {
        if (obj instanceof aj)
        {
            if (org.a.i.a.a(getSubjectKeyIdentifier(), ((aj) (obj = (aj)obj)).getSubjectKeyIdentifier()) && a(getSerialNumber(), ((aj) (obj)).getSerialNumber()) && a(getIssuerAsString(), ((aj) (obj)).getIssuerAsString()))
            {
                return true;
            }
        }
        return false;
    }

    public int hashCode()
    {
        int j = org.a.i.a.a(getSubjectKeyIdentifier());
        int i = j;
        if (getSerialNumber() != null)
        {
            i = j ^ getSerialNumber().hashCode();
        }
        j = i;
        if (getIssuerAsString() != null)
        {
            j = i ^ getIssuerAsString().hashCode();
        }
        return j;
    }
}
