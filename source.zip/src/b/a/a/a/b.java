// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package b.a.a.a;

import java.io.Serializable;
import org.apache.harmony.awt.a.a.a;
import org.apache.harmony.awt.gl.color.NativeCMM;

// Referenced classes of package b.a.a.a:
//            a, d, c, e

public class b
    implements Serializable
{

    private transient long a;
    private transient boolean b;
    private transient byte c[];

    b()
    {
        a = 0L;
        b = false;
        c = null;
    }

    b(long l)
    {
        a = 0L;
        b = false;
        c = null;
        a = l;
        NativeCMM.a(this, l);
    }

    private b(byte abyte0[])
    {
        a = 0L;
        b = false;
        c = null;
        a = NativeCMM.cmmOpenProfile(abyte0);
        NativeCMM.a(this, a);
    }

    public static b a(byte abyte0[])
    {
        d d1;
        try
        {
            abyte0 = new b(abyte0);
        }
        // Misplaced declaration of an exception variable
        catch (byte abyte0[])
        {
            throw new IllegalArgumentException(org.apache.harmony.awt.a.a.a.a("awt.162"));
        }
        if (System.getProperty("os.name").toLowerCase().indexOf("windows") < 0)
        {
            break MISSING_BLOCK_LABEL_168;
        }
        if (abyte0.c() != 5 || abyte0.d(0x77747074) <= 0 || abyte0.d(0x7258595a) <= 0 || abyte0.d(0x6758595a) <= 0 || abyte0.d(0x6258595a) <= 0 || abyte0.d(0x72545243) <= 0 || abyte0.d(0x67545243) <= 0 || abyte0.d(0x62545243) <= 0)
        {
            break MISSING_BLOCK_LABEL_124;
        }
        d1 = new d(abyte0.d());
        return d1;
        c c1;
        try
        {
            if (abyte0.c() != 6 || abyte0.d(0x77747074) <= 0 || abyte0.d(0x6b545243) <= 0)
            {
                break MISSING_BLOCK_LABEL_168;
            }
            c1 = new c(abyte0.d());
        }
        catch (b.a.a.a.a a1)
        {
            return abyte0;
        }
        return c1;
        return abyte0;
    }

    private int b(int i)
    {
        if (c == null)
        {
            c = a(0x68656164);
        }
        return (c[i] & 0xff) << 24 | (c[i + 1] & 0xff) << 16 | (c[i + 2] & 0xff) << 8 | c[i + 3] & 0xff;
    }

    private int c(int i)
    {
        switch (i)
        {
        default:
            throw new IllegalArgumentException(org.apache.harmony.awt.a.a.a.a("awt.165"));

        case 1380401696: 
            return 5;

        case 1482250784: 
            return 0;

        case 1129142603: 
            return 9;

        case 1281450528: 
            return 1;

        case 1196573017: 
            return 6;

        case 1212961568: 
            return 8;

        case 1282766368: 
            return 2;

        case 1497588338: 
            return 3;

        case 1501067552: 
            return 4;

        case 1213421088: 
            return 7;

        case 1129142560: 
            return 11;

        case 843271250: 
            return 12;

        case 860048466: 
            return 13;

        case 876825682: 
            return 14;

        case 893602898: 
            return 15;

        case 910380114: 
            return 16;

        case 927157330: 
            return 17;

        case 943934546: 
            return 18;

        case 960711762: 
            return 19;

        case 1094929490: 
            return 20;

        case 1111706706: 
            return 21;

        case 1128483922: 
            return 22;

        case 1145261138: 
            return 23;

        case 1162038354: 
            return 24;

        case 1178815570: 
            return 25;
        }
    }

    private int d(int i)
    {
        return NativeCMM.cmmGetProfileElementSize(a, i);
    }

    private long d()
    {
        b = true;
        return a;
    }

    public byte[] a()
    {
        byte abyte0[] = new byte[NativeCMM.cmmGetProfileSize(a)];
        NativeCMM.cmmGetProfile(a, abyte0);
        return abyte0;
    }

    public byte[] a(int i)
    {
        byte abyte0[];
        int j;
        try
        {
            j = NativeCMM.cmmGetProfileElementSize(a, i);
        }
        catch (b.a.a.a.a a1)
        {
            return null;
        }
        abyte0 = new byte[j];
        NativeCMM.cmmGetProfileElement(a, i, abyte0);
        return abyte0;
    }

    public int b()
    {
        byte byte0 = 3;
        switch (b(16))
        {
        default:
            throw new e(org.apache.harmony.awt.a.a.a.a("awt.160"));

        case 1129142603: 
            byte0 = 4;
            // fall through

        case 860048466: 
        case 1129142560: 
        case 1212961568: 
        case 1213421088: 
        case 1281450528: 
        case 1282766368: 
        case 1380401696: 
        case 1482250784: 
        case 1497588338: 
        case 1501067552: 
            return byte0;

        case 1196573017: 
            return 1;

        case 843271250: 
            return 2;

        case 876825682: 
            return 4;

        case 893602898: 
            return 5;

        case 910380114: 
            return 6;

        case 927157330: 
            return 7;

        case 943934546: 
            return 8;

        case 960711762: 
            return 9;

        case 1094929490: 
            return 10;

        case 1111706706: 
            return 11;

        case 1128483922: 
            return 12;

        case 1145261138: 
            return 13;

        case 1162038354: 
            return 14;

        case 1178815570: 
            return 15;
        }
    }

    public int c()
    {
        return c(b(16));
    }

    protected void finalize()
    {
        if (a != 0L && !b)
        {
            NativeCMM.cmmCloseProfile(a);
        }
        NativeCMM.a(this);
    }
}
