// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package b.a.a;

import b.a.a.b.f;
import java.io.Serializable;

public class d extends f
    implements Serializable
{

    public int a;
    public int b;

    public d()
    {
        a(0, 0);
    }

    public d(int i, int j)
    {
        a(i, j);
    }

    public double a()
    {
        return (double)a;
    }

    public void a(int i, int j)
    {
        a = i;
        b = j;
    }

    public double b()
    {
        return (double)b;
    }

    public boolean equals(Object obj)
    {
        if (obj != this)
        {
            if (obj instanceof d)
            {
                if (a != ((d) (obj = (d)obj)).a || b != ((d) (obj)).b)
                {
                    return false;
                }
            } else
            {
                return false;
            }
        }
        return true;
    }

    public String toString()
    {
        return (new StringBuilder(String.valueOf(getClass().getName()))).append("[x=").append(a).append(",y=").append(b).append("]").toString();
    }
}
