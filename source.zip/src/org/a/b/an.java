// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.io.IOException;
import java.security.Key;
import java.security.Provider;
import javax.crypto.SecretKey;
import org.a.a.be;
import org.a.a.t.a;

// Referenced classes of package org.a.b:
//            q, g, aa, y, 
//            p, k, a, am

public abstract class an
{

    private q a;
    private org.a.b.a b;
    protected am c;
    protected a d;
    protected a e;

    an(a a1, a a2, q q1, org.a.b.a a3)
    {
        d = a1;
        e = a2;
        a = q1;
        b = a3;
    }

    String a()
    {
        a a1 = a.a();
        return org.a.b.g.a.c(a1.f().e());
    }

    public abstract y a(Key key, Provider provider);

    public byte[] a(Key key, String s)
    {
        return d(key, org.a.b.aa.a(s));
    }

    public am b()
    {
        return c;
    }

    protected y c(Key key, Provider provider)
    {
        key = a.a((SecretKey)key, provider);
        try
        {
            key = new y(key.a());
        }
        // Misplaced declaration of an exception variable
        catch (Key key)
        {
            throw new k("error getting .", key);
        }
        return key;
    }

    public byte[] d(Key key, Provider provider)
    {
        try
        {
            key = org.a.b.aa.a(a(key, provider).a());
        }
        // Misplaced declaration of an exception variable
        catch (Key key)
        {
            throw new RuntimeException((new StringBuilder("unable to parse internal stream: ")).append(key).toString());
        }
        return key;
    }
}
