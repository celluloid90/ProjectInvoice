// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.io.BufferedInputStream;
import java.io.InputStream;
import org.a.a.m;
import org.a.a.n.c;

// Referenced classes of package org.a.b:
//            z

public class y
{

    private final m a;
    private final InputStream b;

    public y(InputStream inputstream)
    {
        this(c.M.e(), inputstream, 32768);
    }

    public y(String s, InputStream inputstream, int i)
    {
        this(new m(s), inputstream, i);
    }

    public y(m m1, InputStream inputstream, int i)
    {
        a = m1;
        b = new z(new BufferedInputStream(inputstream, i));
    }

    public InputStream a()
    {
        return b;
    }
}
