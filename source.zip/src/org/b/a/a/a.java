// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.b.a.a;


// Referenced classes of package org.b.a.a:
//            b, d

public abstract class a extends org.b.a.a
{

    private Exception a;
    public final d g = (new b(this)).a(new Void[0]);

    public a()
    {
        a = null;
    }

    static Exception a(a a1)
    {
        return a1.a;
    }

    static Exception a(a a1, Exception exception)
    {
        a1.a = exception;
        return exception;
    }

    static void a(a a1, Object obj)
    {
        a1.b(obj);
    }

    static void b(a a1, Object obj)
    {
        a1.a(obj);
    }

    static void c(a a1, Object obj)
    {
        a1.b(obj);
    }

    static void d(a a1, Object obj)
    {
        a1.c(obj);
    }

    protected abstract Object b();

    protected abstract Object b(Exception exception);

    protected Object d(Object obj)
    {
        return null;
    }
}
