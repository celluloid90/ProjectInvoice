// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.g;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.a.a.ba;
import org.a.a.bb;
import org.a.a.be;
import org.a.a.j.b;
import org.a.a.n.c;
import org.a.a.n.f;
import org.a.a.p.p;
import org.a.a.u.ai;

// Referenced classes of package org.a.g:
//            b

public class a
    implements org.a.g.b
{

    private static Map a;
    private static Set b;
    private static Map c;
    private static Set d;
    private static Map e;
    private static final be f;
    private static final be g;
    private static final be h;
    private static final be i;
    private static final be j;
    private static final be k;

    public a()
    {
    }

    private static f a(org.a.a.t.a a1, int l)
    {
        return new f(a1, new org.a.a.t.a(c.l_, a1), new ba(l), new ba(1));
    }

    static 
    {
        a = new HashMap();
        b = new HashSet();
        c = new HashMap();
        d = new HashSet();
        e = new HashMap();
        f = c.h_;
        g = ai.V;
        h = ai.i;
        i = c.k;
        j = org.a.a.d.a.c;
        k = org.a.a.d.a.d;
        a.put("MD2WITHRSAENCRYPTION", c.i_);
        a.put("MD2WITHRSA", c.i_);
        a.put("MD5WITHRSAENCRYPTION", c.e);
        a.put("MD5WITHRSA", c.e);
        a.put("SHA1WITHRSAENCRYPTION", c.j_);
        a.put("SHA1WITHRSA", c.j_);
        a.put("SHA224WITHRSAENCRYPTION", c.p_);
        a.put("SHA224WITHRSA", c.p_);
        a.put("SHA256WITHRSAENCRYPTION", c.m_);
        a.put("SHA256WITHRSA", c.m_);
        a.put("SHA384WITHRSAENCRYPTION", c.n_);
        a.put("SHA384WITHRSA", c.n_);
        a.put("SHA512WITHRSAENCRYPTION", c.o_);
        a.put("SHA512WITHRSA", c.o_);
        a.put("SHA1WITHRSAANDMGF1", c.k);
        a.put("SHA224WITHRSAANDMGF1", c.k);
        a.put("SHA256WITHRSAANDMGF1", c.k);
        a.put("SHA384WITHRSAANDMGF1", c.k);
        a.put("SHA512WITHRSAANDMGF1", c.k);
        a.put("RIPEMD160WITHRSAENCRYPTION", p.f);
        a.put("RIPEMD160WITHRSA", p.f);
        a.put("RIPEMD128WITHRSAENCRYPTION", p.g);
        a.put("RIPEMD128WITHRSA", p.g);
        a.put("RIPEMD256WITHRSAENCRYPTION", p.h);
        a.put("RIPEMD256WITHRSA", p.h);
        a.put("SHA1WITHDSA", ai.V);
        a.put("DSAWITHSHA1", ai.V);
        a.put("SHA224WITHDSA", b.C);
        a.put("SHA256WITHDSA", b.D);
        a.put("SHA384WITHDSA", b.E);
        a.put("SHA512WITHDSA", b.F);
        a.put("SHA1WITHECDSA", ai.i);
        a.put("ECDSAWITHSHA1", ai.i);
        a.put("SHA224WITHECDSA", ai.m);
        a.put("SHA256WITHECDSA", ai.n);
        a.put("SHA384WITHECDSA", ai.o);
        a.put("SHA512WITHECDSA", ai.p);
        a.put("GOST3411WITHGOST3410", org.a.a.d.a.e);
        a.put("GOST3411WITHGOST3410-94", org.a.a.d.a.e);
        a.put("GOST3411WITHECGOST3410", org.a.a.d.a.f);
        a.put("GOST3411WITHECGOST3410-2001", org.a.a.d.a.f);
        a.put("GOST3411WITHGOST3410-2001", org.a.a.d.a.f);
        b.add(ai.i);
        b.add(ai.m);
        b.add(ai.n);
        b.add(ai.o);
        b.add(ai.p);
        b.add(ai.V);
        b.add(b.C);
        b.add(b.D);
        b.add(b.E);
        b.add(b.F);
        b.add(org.a.a.d.a.e);
        b.add(org.a.a.d.a.f);
        d.add(c.j_);
        d.add(c.p_);
        d.add(c.m_);
        d.add(c.n_);
        d.add(c.o_);
        d.add(p.g);
        d.add(p.f);
        d.add(p.h);
        org.a.a.t.a a1 = new org.a.a.t.a(org.a.a.m.b.i, new bb());
        c.put("SHA1WITHRSAANDMGF1", a(a1, 20));
        a1 = new org.a.a.t.a(b.e, new bb());
        c.put("SHA224WITHRSAANDMGF1", a(a1, 28));
        a1 = new org.a.a.t.a(b.b, new bb());
        c.put("SHA256WITHRSAANDMGF1", a(a1, 32));
        a1 = new org.a.a.t.a(b.c, new bb());
        c.put("SHA384WITHRSAANDMGF1", a(a1, 48));
        a1 = new org.a.a.t.a(b.d, new bb());
        c.put("SHA512WITHRSAANDMGF1", a(a1, 64));
        e.put(c.p_, b.e);
        e.put(c.m_, b.b);
        e.put(c.n_, b.c);
        e.put(c.o_, b.d);
        e.put(c.i_, c.E);
        e.put(c.d, c.F);
        e.put(c.e, c.G);
        e.put(c.j_, org.a.a.m.b.i);
        e.put(p.g, p.c);
        e.put(p.f, p.b);
        e.put(p.h, p.d);
        e.put(org.a.a.d.a.e, org.a.a.d.a.a);
        e.put(org.a.a.d.a.f, org.a.a.d.a.a);
    }
}
