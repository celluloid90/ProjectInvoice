// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.security.AlgorithmParameters;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import java.security.spec.InvalidParameterSpecException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import org.a.a.c.j;
import org.a.a.c.l;
import org.a.a.c.m;
import org.a.a.c.s;
import org.a.a.c.v;
import org.a.a.n.c;
import org.a.a.t;
import org.a.a.t.a;

// Referenced classes of package org.a.b:
//            f, j, k, ao, 
//            ai, ae, ag, al, 
//            q, a

class g
{

    static final g a = new g();
    private static final Map b;
    private static final Map c;
    private static final Map d;
    private static final Map e;

    g()
    {
    }

    static Object a(org.a.b.j j1)
    {
        try
        {
            j1 = ((org.a.b.j) (j1.a()));
        }
        // Misplaced declaration of an exception variable
        catch (org.a.b.j j1)
        {
            throw new k("can't find algorithm.", j1);
        }
        // Misplaced declaration of an exception variable
        catch (org.a.b.j j1)
        {
            throw new k("key invalid in message.", j1);
        }
        // Misplaced declaration of an exception variable
        catch (org.a.b.j j1)
        {
            throw new k("required padding not supported.", j1);
        }
        // Misplaced declaration of an exception variable
        catch (org.a.b.j j1)
        {
            throw new k("algorithm parameters invalid.", j1);
        }
        // Misplaced declaration of an exception variable
        catch (org.a.b.j j1)
        {
            throw new k("MAC algorithm parameter spec invalid.", j1);
        }
        return j1;
    }

    static ao a(t t1, a a1, q q)
    {
        return a(t1, a1, q, null);
    }

    static ao a(t t1, a a1, q q, org.a.b.a a2)
    {
        ArrayList arraylist = new ArrayList();
        int i = 0;
        do
        {
            if (i == t1.f())
            {
                return new ao(arraylist);
            }
            a(((List) (arraylist)), v.a(t1.a(i)), a1, q, a2);
            i++;
        } while (true);
    }

    private static void a(List list, v v1, a a1, q q, org.a.b.a a2)
    {
        v1 = v1.f();
        if (v1 instanceof m)
        {
            list.add(new ai((m)v1, a1, q, a2));
        } else
        {
            if (v1 instanceof j)
            {
                list.add(new ae((j)v1, a1, q, a2));
                return;
            }
            if (v1 instanceof l)
            {
                org.a.b.ag.a(list, (l)v1, a1, q, a2);
                return;
            }
            if (v1 instanceof s)
            {
                list.add(new al((s)v1, a1, q, a2));
                return;
            }
        }
    }

    private Cipher d(String s1, Provider provider)
    {
        if (provider != null)
        {
            return Cipher.getInstance(s1, provider);
        } else
        {
            return Cipher.getInstance(s1);
        }
    }

    private AlgorithmParameters e(String s1, Provider provider)
    {
        if (provider != null)
        {
            return AlgorithmParameters.getInstance(s1, provider);
        } else
        {
            return AlgorithmParameters.getInstance(s1);
        }
    }

    String a(String s1)
    {
        String s2 = s1;
        if (c.h_.e().equals(s1))
        {
            s2 = "RSA/ECB/PKCS1Padding";
        }
        return s2;
    }

    Cipher a(String s1, Provider provider)
    {
        Object obj;
        obj = a(s1);
        if (((String) (obj)).equals(s1))
        {
            break MISSING_BLOCK_LABEL_24;
        }
        obj = d(((String) (obj)), provider);
        return ((Cipher) (obj));
        NoSuchAlgorithmException nosuchalgorithmexception;
        nosuchalgorithmexception;
        return d(s1, provider);
    }

    String b(String s1)
    {
        String s2 = (String)c.get(s1);
        if (s2 == null)
        {
            throw new IllegalArgumentException((new StringBuilder("no name for ")).append(s1).toString());
        } else
        {
            return (new StringBuilder(String.valueOf(s2))).append("RFC3211Wrap").toString();
        }
    }

    AlgorithmParameters b(String s1, Provider provider)
    {
        AlgorithmParameters algorithmparameters = e(s1, provider);
        return algorithmparameters;
        NoSuchAlgorithmException nosuchalgorithmexception;
        nosuchalgorithmexception;
        s1 = (String)c.get(s1);
        if (s1 == null)
        {
            break MISSING_BLOCK_LABEL_37;
        }
        s1 = e(s1, provider);
        return s1;
        s1;
        throw nosuchalgorithmexception;
    }

    String c(String s1)
    {
        String s2 = (String)c.get(s1);
        if (s2 != null)
        {
            return s2;
        } else
        {
            return s1;
        }
    }

    Cipher c(String s1, Provider provider)
    {
        Cipher cipher;
        try
        {
            cipher = d(s1, provider);
        }
        catch (NoSuchAlgorithmException nosuchalgorithmexception)
        {
            Object obj = (String)d.get(s1);
            try
            {
                obj = d(((String) (obj)), provider);
            }
            catch (NoSuchAlgorithmException nosuchalgorithmexception1)
            {
                if (provider != null)
                {
                    return c(s1, null);
                } else
                {
                    throw nosuchalgorithmexception;
                }
            }
            return ((Cipher) (obj));
        }
        return cipher;
    }

    static 
    {
        b = new HashMap();
        c = new HashMap();
        d = new HashMap();
        e = new HashMap();
        b.put(org.a.b.f.a, new Integer(192));
        b.put(org.a.b.f.c, new Integer(128));
        b.put(f.d, new Integer(192));
        b.put(f.e, new Integer(256));
        c.put(org.a.b.f.a, "DESEDE");
        c.put(org.a.b.f.c, "AES");
        c.put(f.d, "AES");
        c.put(f.e, "AES");
        d.put(org.a.b.f.a, "DESEDE/CBC/PKCS5Padding");
        d.put(org.a.b.f.c, "AES/CBC/PKCS5Padding");
        d.put(f.d, "AES/CBC/PKCS5Padding");
        d.put(f.e, "AES/CBC/PKCS5Padding");
        e.put(org.a.b.f.a, "DESEDEMac");
        e.put(org.a.b.f.c, "AESMac");
        e.put(f.d, "AESMac");
        e.put(f.e, "AESMac");
    }
}
