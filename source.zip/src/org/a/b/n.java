// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import org.a.a.c.d;
import org.a.a.m;

// Referenced classes of package org.a.b:
//            p, x

public class n
    implements p, x
{

    private final m a;
    private final byte b[];

    public n(m m1, byte abyte0[])
    {
        a = m1;
        b = abyte0;
    }

    public n(byte abyte0[])
    {
        this(new m(d.a.e()), abyte0);
    }

    public InputStream a()
    {
        return new ByteArrayInputStream(b);
    }

    public void a(OutputStream outputstream)
    {
        outputstream.write(b);
    }
}
