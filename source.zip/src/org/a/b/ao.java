// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

// Referenced classes of package org.a.b:
//            an

public class ao
{

    private final List a;
    private final Map b = new HashMap();

    public ao(Collection collection)
    {
        Iterator iterator = collection.iterator();
        do
        {
            if (!iterator.hasNext())
            {
                a = new ArrayList(collection);
                return;
            }
            an an1 = (an)iterator.next();
            am am = an1.b();
            ArrayList arraylist1 = (ArrayList)b.get(am);
            ArrayList arraylist = arraylist1;
            if (arraylist1 == null)
            {
                arraylist = new ArrayList(1);
                b.put(am, arraylist);
            }
            arraylist.add(an1);
        } while (true);
    }

    public Collection a()
    {
        return new ArrayList(a);
    }
}
