// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import org.a.a.ap;
import org.a.a.ba;
import org.a.a.c.h;
import org.a.a.c.k;
import org.a.a.c.l;
import org.a.a.c.p;
import org.a.a.c.w;
import org.a.a.m;
import org.a.a.n;
import org.a.a.n.d;
import org.a.a.r;
import org.a.a.s.c;
import org.a.a.t.a;
import org.a.a.t.t;
import org.a.a.t.u;
import org.a.d.c.f;
import org.a.d.c.g;

// Referenced classes of package org.a.b:
//            an, g, f, aj, 
//            k, af, am, q, 
//            a, y

public class ag extends an
{

    private l a;
    private n b;

    ag(l l1, am am, n n1, a a1, q q, org.a.b.a a2)
    {
        super(l1.h(), a1, q, a2);
        a = l1;
        c = am;
        b = n1;
    }

    private Key a(String s, SecretKey secretkey, Provider provider)
    {
        s = org.a.b.g.a.c(s, provider);
        s.init(4, secretkey);
        return s.unwrap(b.f(), a(), 3);
    }

    private PublicKey a(Key key, org.a.a.c.n n1, Provider provider)
    {
        key = new X509EncodedKeySpec(a(d.a(key.getEncoded()).e(), n1).a());
        return KeyFactory.getInstance(d.e().e(), provider).generatePublic(key);
    }

    private PublicKey a(Key key, p p1, Provider provider)
    {
        key = new X509EncodedKeySpec(a(d.a(key.getEncoded()).e(), p1).a());
        return KeyFactory.getInstance(d.e().e(), provider).generatePublic(key);
    }

    private SecretKey a(String s, PublicKey publickey, PrivateKey privatekey, Provider provider)
    {
        String s1 = d.e().e();
        Object obj1 = publickey;
        Object obj = privatekey;
        if (s1.equals(f.s))
        {
            obj1 = new g(publickey, a(((Key) (privatekey)), org.a.a.c.a.a.a(org.a.a.l.a(a.g().f())).e(), provider));
            obj = new f(privatekey, privatekey);
        }
        publickey = KeyAgreement.getInstance(s1, provider);
        publickey.init(((Key) (obj)));
        publickey.doPhase(((Key) (obj1)), true);
        return publickey.generateSecret(s);
    }

    private u a(a a1, org.a.a.c.n n1)
    {
        Object obj = n1.g();
        if (obj != null)
        {
            return a(a1, ((p) (obj)));
        }
        a1 = new aj();
        obj = n1.e();
        if (obj != null)
        {
            a1.setIssuer(((h) (obj)).e().a());
            a1.setSerialNumber(((h) (obj)).f().e());
        } else
        {
            a1.setSubjectKeyIdentifier(n1.f().e());
        }
        return a(((aj) (a1)));
    }

    private u a(a a1, p p1)
    {
        return new u(a1, p1.e().e());
    }

    private u a(aj aj1)
    {
        throw new org.a.b.k("No support for 'originator' as IssuerAndSerialNumber or SubjectKeyIdentifier");
    }

    static void a(List list, l l1, a a1, q q, org.a.b.a a2)
    {
        r r1 = l1.i();
        int i = 0;
        do
        {
            if (i >= r1.f())
            {
                return;
            }
            org.a.a.c.t t1 = org.a.a.c.t.a(r1.a(i));
            Object obj = t1.e();
            h h1 = ((k) (obj)).e();
            if (h1 != null)
            {
                obj = new af(h1.e(), h1.f().e());
            } else
            {
                obj = new af(((k) (obj)).f().e().f());
            }
            list.add(new ag(l1, ((am) (obj)), t1.f(), a1, q, a2));
            i++;
        } while (true);
    }

    public y a(Key key, Provider provider)
    {
        return c(b(key, provider), provider);
    }

    protected Key b(Key key, Provider provider)
    {
        try
        {
            String s = org.a.a.t.a.a(d.g()).e().e();
            key = a(s, a(s, a(key, a.f(), provider), (PrivateKey)key, provider), provider);
        }
        // Misplaced declaration of an exception variable
        catch (Key key)
        {
            throw new org.a.b.k("can't find algorithm.", key);
        }
        // Misplaced declaration of an exception variable
        catch (Key key)
        {
            throw new org.a.b.k("key invalid in message.", key);
        }
        // Misplaced declaration of an exception variable
        catch (Key key)
        {
            throw new org.a.b.k("originator key spec invalid.", key);
        }
        // Misplaced declaration of an exception variable
        catch (Key key)
        {
            throw new org.a.b.k("required padding not supported.", key);
        }
        // Misplaced declaration of an exception variable
        catch (Key key)
        {
            throw new org.a.b.k("originator key invalid.", key);
        }
        return key;
    }
}
