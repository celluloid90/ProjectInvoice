// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.b.a.a;


// Referenced classes of package org.b.a.a:
//            d, a

class b extends d
{

    final a a;

    b(a a1)
    {
        a = a1;
        super();
    }

    protected transient Object a(Void avoid[])
    {
        try
        {
            avoid = ((Void []) (a.b()));
        }
        // Misplaced declaration of an exception variable
        catch (Void avoid[])
        {
            org.b.a.a.a.a(a, avoid);
            return null;
        }
        return avoid;
    }

    protected Object doInBackground(Object aobj[])
    {
        return a((Void[])aobj);
    }

    protected void onCancelled()
    {
        a.a(null);
    }

    protected void onPostExecute(Object obj)
    {
        if (org.b.a.a.a.a(a) != null)
        {
            org.b.a.a.a.a(a, a.b(org.b.a.a.a.a(a)));
            return;
        }
        Object obj1 = a.d(obj);
        if (obj1 == null)
        {
            org.b.a.a.a.b(a, obj);
            return;
        } else
        {
            org.b.a.a.a.c(a, obj1);
            return;
        }
    }

    protected transient void onProgressUpdate(Object aobj[])
    {
        org.b.a.a.a.d(a, aobj[0]);
    }
}
