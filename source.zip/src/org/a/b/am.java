// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.security.cert.X509CertSelector;
import org.a.i.c;

public abstract class am extends X509CertSelector
    implements c
{

    private final int a;

    protected am(int i)
    {
        a = i;
    }
}
