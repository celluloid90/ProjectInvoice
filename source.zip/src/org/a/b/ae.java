// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import org.a.a.be;
import org.a.a.c.i;
import org.a.a.c.j;
import org.a.a.n;
import org.a.a.t.a;

// Referenced classes of package org.a.b:
//            an, ad, g, k, 
//            q, a, y

public class ae extends an
{

    private j a;

    ae(j j1, a a1, q q, org.a.b.a a2)
    {
        super(j1.g(), a1, q, a2);
        a = j1;
        c = new ad(j1.f().e().f());
    }

    public y a(Key key, Provider provider)
    {
        try
        {
            Cipher cipher = org.a.b.g.a.c(d.f().e(), provider);
            cipher.init(4, key);
            key = c(cipher.unwrap(a.h().f(), a(), 3), provider);
        }
        // Misplaced declaration of an exception variable
        catch (Key key)
        {
            throw new k("can't find algorithm.", key);
        }
        // Misplaced declaration of an exception variable
        catch (Key key)
        {
            throw new k("key invalid in message.", key);
        }
        // Misplaced declaration of an exception variable
        catch (Key key)
        {
            throw new k("required padding not supported.", key);
        }
        return key;
    }
}
