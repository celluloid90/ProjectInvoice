// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.io.InputStream;
import java.io.OutputStream;
import org.a.i.b.a;

// Referenced classes of package org.a.b:
//            m, p

class o
    implements m, p
{

    private InputStream a;
    private boolean b;

    public o(InputStream inputstream)
    {
        b = false;
        a = inputstream;
    }

    private void b()
    {
        this;
        JVM INSTR monitorenter ;
        if (b)
        {
            throw new IllegalStateException("CMSProcessableInputStream can only be used once");
        }
        break MISSING_BLOCK_LABEL_24;
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
        b = true;
        this;
        JVM INSTR monitorexit ;
    }

    public InputStream a()
    {
        b();
        return a;
    }

    public void a(OutputStream outputstream)
    {
        b();
        org.a.i.b.a.a(a, outputstream);
        a.close();
    }
}
