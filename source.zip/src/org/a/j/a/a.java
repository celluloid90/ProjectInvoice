// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.j.a;

import org.a.a.l;
import org.a.a.n;

public class a
{

    public static l a(byte abyte0[])
    {
        return l.a(((n)l.a(abyte0)).f());
    }
}
