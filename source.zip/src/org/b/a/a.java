// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.b.a;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

// Referenced classes of package org.b.a:
//            g, h, b, c, 
//            d, j, i, f, 
//            e

public class a
    implements g
{

    private h a;
    private Object b;
    protected final List c = new CopyOnWriteArrayList();
    protected final List d = new CopyOnWriteArrayList();
    protected final List e = new CopyOnWriteArrayList();
    protected final List f = new CopyOnWriteArrayList();
    private Object g;

    public a()
    {
        a = h.a;
    }

    public g a(d d1)
    {
        return a(null, null, null, d1);
    }

    public g a(e e1)
    {
        b(new b(this, e1));
        a(((i) (new c(this, e1))));
        return this;
    }

    public g a(i k)
    {
        return a(null, k);
    }

    public g a(j j1)
    {
        return a(j1, null, null);
    }

    public g a(j j1, i k)
    {
        return a(j1, k, null);
    }

    public g a(j j1, i k, f f1)
    {
        return a(j1, k, f1, null);
    }

    public g a(j j1, i k, f f1, d d1)
    {
        if (j1 != null)
        {
            c.add(j1);
        }
        if (k != null)
        {
            d.add(k);
        }
        if (f1 != null)
        {
            e.add(f1);
        }
        if (d1 != null)
        {
            f.add(d1);
        }
        if (d1 != null && !c())
        {
            d1.a(b, g);
        }
        if (j1 != null && e())
        {
            j1.a(b);
        }
        if (k != null && d())
        {
            k.a(g);
        }
        return this;
    }

    protected void a(Object obj)
    {
        b = obj;
        a = h.c;
        f();
    }

    public g b(j j1)
    {
        return a(j1);
    }

    protected void b(Object obj)
    {
        g = obj;
        a = h.b;
        g();
    }

    protected void c(Object obj)
    {
        if (h.a.compareTo(a) >= 0)
        {
            Iterator iterator = e.iterator();
            while (iterator.hasNext()) 
            {
                ((f)iterator.next()).a(obj);
            }
        }
    }

    public boolean c()
    {
        return h.a == a;
    }

    public boolean d()
    {
        return h.b == a;
    }

    public boolean e()
    {
        return h.c == a;
    }

    protected final void f()
    {
        h();
        for (Iterator iterator = c.iterator(); iterator.hasNext(); ((j)iterator.next()).a(b)) { }
    }

    protected final void g()
    {
        h();
        for (Iterator iterator = d.iterator(); iterator.hasNext(); ((i)iterator.next()).a(g)) { }
    }

    protected final void h()
    {
        Iterator iterator = f.iterator();
        while (iterator.hasNext()) 
        {
            d d1 = (d)iterator.next();
            Object obj;
            Object obj1;
            if (e())
            {
                obj = b;
            } else
            {
                obj = null;
            }
            if (d())
            {
                obj1 = g;
            } else
            {
                obj1 = null;
            }
            d1.a(obj, obj1);
        }
    }

    public g i()
    {
        return this;
    }
}
