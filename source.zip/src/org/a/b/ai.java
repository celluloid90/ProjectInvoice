// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package org.a.b;

import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import java.security.ProviderException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import org.a.a.ba;
import org.a.a.be;
import org.a.a.c.h;
import org.a.a.c.m;
import org.a.a.c.u;
import org.a.a.n;
import org.a.a.n.c;
import org.a.a.t.a;

// Referenced classes of package org.a.b:
//            an, ah, g, k, 
//            q, a, y

public class ai extends an
{

    private m a;

    ai(m m1, a a1, q q, org.a.b.a a2)
    {
        super(m1.g(), a1, q, a2);
        a = m1;
        m1 = m1.f();
        if (m1.e())
        {
            c = new ah(n.a(m1.f()).f());
            return;
        } else
        {
            m1 = h.a(m1.f());
            c = new ah(m1.e(), m1.f().e());
            return;
        }
    }

    private String a(be be1)
    {
        if (c.h_.equals(be1))
        {
            return "RSA/ECB/PKCS1Padding";
        } else
        {
            return be1.e();
        }
    }

    public y a(Key key, Provider provider)
    {
        return c(b(key, provider), provider);
    }

    protected Key b(Key key, Provider provider)
    {
        Object obj;
        Object obj1;
        String s;
        obj1 = org.a.b.g.a;
        s = a(d.f());
        obj = null;
        byte abyte0[];
        String s1;
        obj1 = ((g) (obj1)).a(s, provider);
        abyte0 = a.h().f();
        s1 = a();
        try
        {
            ((Cipher) (obj1)).init(4, key);
            provider = ((Cipher) (obj1)).unwrap(abyte0, s1, 3);
        }
        // Misplaced declaration of an exception variable
        catch (Provider provider)
        {
            provider = ((Provider) (obj));
        }
        // Misplaced declaration of an exception variable
        catch (Provider provider)
        {
            provider = ((Provider) (obj));
        }
        // Misplaced declaration of an exception variable
        catch (Provider provider)
        {
            provider = ((Provider) (obj));
        }
        // Misplaced declaration of an exception variable
        catch (Provider provider)
        {
            provider = ((Provider) (obj));
        }
        obj = provider;
        if (provider == null)
        {
            try
            {
                ((Cipher) (obj1)).init(2, key);
                obj = new SecretKeySpec(((Cipher) (obj1)).doFinal(abyte0), s1);
            }
            // Misplaced declaration of an exception variable
            catch (Key key)
            {
                throw new k("can't find algorithm.", key);
            }
            // Misplaced declaration of an exception variable
            catch (Key key)
            {
                throw new k("key invalid in message.", key);
            }
            // Misplaced declaration of an exception variable
            catch (Key key)
            {
                throw new k("required padding not supported.", key);
            }
            // Misplaced declaration of an exception variable
            catch (Key key)
            {
                throw new k("illegal blocksize in message.", key);
            }
            // Misplaced declaration of an exception variable
            catch (Key key)
            {
                throw new k("bad padding in message.", key);
            }
        }
        return ((Key) (obj));
    }
}
